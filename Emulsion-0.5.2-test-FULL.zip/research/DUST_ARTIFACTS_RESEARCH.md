# Dust & film-artifact module — research note

## Public reference corpus

Ivanova, D., Williamson, J., Henderson, P. (2023), “Simulating analogue film damage to analyse and improve artefact restoration on high-resolution scans”, Computer Graphics Forum 42(2), 133–148. DOI: 10.1111/cgf.14749.

Project: https://github.com/daniela997/FilmDamageSimulator
Project page: https://daniela997.github.io/FilmDamageSimulator/

The paper describes 10 heavily damaged, empty 35 mm frames scanned at 4K and manually annotated. The authors report 12,135 individual artifacts: dust, dirt, short hairs, long hairs and scratches. The dataset records individual polygons and statistics for area, counts and spatial distribution. Their model uses empirical size/count distributions and a spatial-density approximation rather than placing identical dots uniformly.

The repository contains an MIT license for its software. That license must not automatically be assumed to cover every third-party scan/image asset. The paper separately notes that the 44-image evaluation set was shot/scanned by Dmitri Tcherbadji and used with permission. For that reason, this Android archive does not redistribute copied scan crops. The real-image bank remains a separate integration task pending explicit asset-level redistribution confirmation and acquisition of the original files.

## Current Android implementation

`GrainRenderer.applyDust` currently renders a deterministic procedural overlay from 50 seeded irregular-shape archetypes. This provides a working test implementation for:

- black, white and mixed dust;
- density control;
- size control;
- Gaussian softening;
- independent deterministic dust seed / reroll;
- preview and full-resolution export, because both call the same renderer.

Important: these 50 archetypes are procedural placeholders, not 50 real photographic samples. Their shapes are varied polygons, not extracted scans. The interface explicitly says so. The implementation does not yet reproduce the paper's fitted Gamma distributions or its non-uniform spatial-density field. Those should be added only after importing and validating the annotation/crop bank.

## Planned real-bank integration

1. Obtain the original scan files and annotation JSON from the project repository.
2. Verify asset-level rights for redistribution in Emulsion; preserve attribution and notices.
3. Extract dust-only crops using the published polygons; retain a source manifest with scan, annotation ID, crop bounds, source dimensions and physical scale.
4. Store normalized alpha masks in `app/src/main/assets/dust/` (or a compact atlas) and sample them without resizing beyond controlled interpolation.
5. Fit and implement the reported size/count and frame-position statistics, separately from synthetic procedural fallback.
6. Validate generated overlays against real held-out scans using size histograms, spatial-density maps and visual review.
