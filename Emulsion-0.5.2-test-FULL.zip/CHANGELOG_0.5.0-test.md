# Emulsion 0.5.0-test

- Added a dedicated dust/artifacts layer.
- Added black, white and mixed dust modes.
- Added density, scale and blur controls.
- Added deterministic randomization via an independent dust seed.
- Current 50-shape bank is procedural and explicitly not represented as real scanned dust.
- Real-scan crop library is pending source-asset acquisition and redistribution review.
