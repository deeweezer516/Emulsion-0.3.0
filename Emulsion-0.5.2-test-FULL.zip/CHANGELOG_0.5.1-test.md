# Emulsion 0.5.1-test

## Dust rendering calibration
- Reduced particle count to a sparse area-scaled distribution; density slider now controls a practical number of defects rather than thousands of specks.
- Reduced default particle opacity to avoid the pasted-on sticker appearance.
- Corrected blur to operate on coverage masks only, preserving black/white polarity and avoiding RGB contamination from transparent pixels.
- Dust blur scales with image resolution so preview and full-resolution export remain visually consistent.
- Particle size remains resolution-scaled; seed remains deterministic and the randomize control produces a new arrangement.
- Dust settings continue to be passed into both preview and full-resolution export.
