# Emulsion 0.5.2-test

## Dust rendering crash fix
- Replaced full-resolution black/white ARGB dust masks and multiple pixel arrays with direct Canvas drawing onto one mutable bitmap copy.
- Removed full-frame CPU blur arrays from the dust stage.
- Dust blur now uses Android's BlurMaskFilter on individual particle shapes.
- Preserved black, white, and mixed dust modes, density, size, blur and deterministic seed.
- This substantially reduces peak memory allocated specifically by the dust stage. Full-device testing is still required.
