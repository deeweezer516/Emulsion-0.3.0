package com.emulsion.editor

/**
 * Physically-inspired stochastic grain model.
 * This is a research prototype, not yet calibrated to a named commercial emulsion.
 * Grain is represented by correlated random fields at several spatial scales,
 * with a signal-dependent variance curve and partially correlated RGB channels.
 */
data class GrainSettings(
    val amount: Float = 0.42f,
    val grainDiameterMicrons: Float = 9.0f,
    val sizeSpread: Float = 0.62f,
    val clumping: Float = 0.48f,
    val toneDependence: Float = 0.72f,
    val chroma: Float = 0.18f,
    val format: FilmFormat = FilmFormat.MM35,
    val model: GrainModelMode = GrainModelMode.CORRELATED_FIELD,
    val monochrome: Boolean = false, // neutral grain across RGB channels
    val blackAndWhite: Boolean = false, // convert the photograph itself to grayscale
    val vintage: Float = 0f, // subtle optical softness, sigma up to 1.4 px
    val shadowResponse: Float = 0.75f,
    val highlightResponse: Float = 0.55f,
    val seed: Long = 73421L
)

enum class GrainModelMode(val label: String) {
    CORRELATED_FIELD("Коррелированное поле"),
    PARTICLE_FIELD("Частичное поле · эксперимент")
}

enum class FilmFormat(val label: String, val widthMm: Float) {
    MM35("35 mm", 36f),
    MEDIUM("120 / 6×6", 56f),
    LARGE("4×5 inch", 127f)
}

object GrainRenderer {
    /**
     * Renders a full-resolution ARGB_8888 bitmap. Caller should execute off the UI thread.
     * The source is treated as a positive scan; luminance is used as a proxy for negative
     * exposure. A calibrated implementation will replace this proxy with measured H-D curves.
     */
    fun render(source: android.graphics.Bitmap, settings: GrainSettings): android.graphics.Bitmap {
        val w = source.width
        val h = source.height
        val inputRow = IntArray(w)
        val outputRow = IntArray(w)
        val output = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)

        val grainPx = (settings.grainDiameterMicrons / (settings.format.widthMm * 1000f) * w)
            .coerceIn(0.55f, 8.0f)
        val spread = settings.sizeSpread.coerceIn(0f, 1f)
        val clump = settings.clumping.coerceIn(0f, 1f)
        val tone = settings.toneDependence.coerceIn(0f, 1f)
        val chroma = settings.chroma.coerceIn(0f, 1f)
        val amount = settings.amount.coerceIn(0f, 1f)
        val shadowResponse = settings.shadowResponse.coerceIn(0f, 1f)
        val highlightResponse = settings.highlightResponse.coerceIn(0f, 1f)

        // Coarse random fields create correlated grain clouds; a deterministic per-pixel
        // field retains particle-scale variation without allocating full-frame noise planes.
        val midCell = (grainPx * (2.2f + clump * 2.8f)).coerceAtLeast(2.0f)
        val coarseCell = (grainPx * (6.0f + clump * 7.0f)).coerceAtLeast(4.0f)
        val mid = NoiseField(w, h, midCell, settings.seed xor 0x6B21L)
        val coarse = NoiseField(w, h, coarseCell, settings.seed xor 0x44D3L)

        val commonWeight = (1f - chroma * 0.62f).coerceIn(0.25f, 1f)
        val independentWeight = (chroma * 0.72f)
        val midWeight = 0.30f + clump * 0.12f
        val coarseWeight = 0.10f + clump * 0.18f
        val fineWeight = 0.78f - spread * 0.12f
        val norm = 1f / (fineWeight + midWeight + coarseWeight)
        val scale = amount * 0.075f

        for (y in 0 until h) {
            source.getPixels(inputRow, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val p = inputRow[x]
                val a = (p ushr 24) and 0xff
                val sr = ((p ushr 16) and 0xff) / 255f
                val sg = ((p ushr 8) and 0xff) / 255f
                val sb = (p and 0xff) / 255f

                // Convert sRGB to linear light before adding density-like fluctuations.
                var r = srgbToLinear(sr)
                var g = srgbToLinear(sg)
                var b = srgbToLinear(sb)
                if (settings.blackAndWhite) {
                    val luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b
                    r = luminance
                    g = luminance
                    b = luminance
                }
                val yLum = (0.2126f * r + 0.7152f * g + 0.0722f * b).coerceIn(0f, 1f)

                val fineNoise = uniformNoise(x, y, settings.seed xor 0x19A4L)
                val field = (fineNoise * fineWeight +
                    mid.sample(x, y) * midWeight + coarse.sample(x, y) * coarseWeight) * norm
                // Experimental thresholded field evokes clustered particle occupancy. It is
                // not the validated Boolean disk/overlap model from the Python research bench.
                val base = if (settings.model == GrainModelMode.PARTICLE_FIELD) {
                    val thresholded = if (field > 0.18f) 0.72f else -0.38f
                    (thresholded * 0.72f + field * 0.28f)
                } else field

                // A smooth variance curve: grain strength depends on local signal, rather
                // than being a constant-amplitude overlay. Kept nonzero near both endpoints.
                val exposureProxy = yLum.coerceIn(0.015f, 0.985f)
                val shadow = shadowResponse * (1f - kotlin.math.sqrt(exposureProxy))
                val highlight = highlightResponse * kotlin.math.sqrt(exposureProxy)
                val densityResponse = (0.20f + 0.55f * kotlin.math.sqrt(exposureProxy) + 0.25f * (shadow + highlight))
                val toneCurve = (1f - tone) + tone * densityResponse
                val sigma = scale * toneCurve

                val nr = base * commonWeight + uniformNoise(x, y, settings.seed xor 0x12345L) * independentWeight
                val ng = base * commonWeight + uniformNoise(x, y, settings.seed xor 0x6789AL) * independentWeight
                val nb = base * commonWeight + uniformNoise(x, y, settings.seed xor 0xABCDEFL) * independentWeight

                val monoNoise = (nr + ng + nb) / 3f
                val rr = linearToSrgb((r + (if (settings.monochrome) monoNoise else nr) * sigma).coerceIn(0f, 1f))
                val gg = linearToSrgb((g + (if (settings.monochrome) monoNoise else ng) * sigma).coerceIn(0f, 1f))
                val bb = linearToSrgb((b + (if (settings.monochrome) monoNoise else nb) * sigma).coerceIn(0f, 1f))
                outputRow[x] = (a shl 24) or
                    ((rr * 255f + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                    ((gg * 255f + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                    (bb * 255f + 0.5f).toInt().coerceIn(0, 255)
            }
            output.setPixels(outputRow, 0, w, 0, y, w, 1)
        }
        return applyVintageSoftness(output, settings.vintage)
    }

    /** Separable Gaussian low-pass applied after grain, so both image detail and grain soften. */
    private fun applyVintageSoftness(bitmap: android.graphics.Bitmap, amount: Float): android.graphics.Bitmap {
        val sigma = amount.coerceIn(0f, 1f) * 1.4f
        if (sigma < 0.08f) return bitmap
        val radius = kotlin.math.ceil(sigma * 3f).toInt().coerceIn(1, 5)
        val kernel = FloatArray(radius * 2 + 1)
        var total = 0f
        for (i in -radius..radius) {
            val weight = kotlin.math.exp(-(i * i).toFloat() / (2f * sigma * sigma))
            kernel[i + radius] = weight
            total += weight
        }
        for (i in kernel.indices) kernel[i] /= total
        val w = bitmap.width
        val h = bitmap.height
        val src = IntArray(w * h)
        val tmp = IntArray(w * h)
        val dst = IntArray(w * h)
        bitmap.getPixels(src, 0, w, 0, 0, w, h)
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0f; var r = 0f; var g = 0f; var b = 0f
            for (k in -radius..radius) {
                val p = src[y * w + (x + k).coerceIn(0, w - 1)]
                val q = kernel[k + radius]
                a += ((p ushr 24) and 255) * q; r += ((p ushr 16) and 255) * q
                g += ((p ushr 8) and 255) * q; b += (p and 255) * q
            }
            tmp[y * w + x] = (a.toInt().coerceIn(0,255) shl 24) or (r.toInt().coerceIn(0,255) shl 16) or (g.toInt().coerceIn(0,255) shl 8) or b.toInt().coerceIn(0,255)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0f; var r = 0f; var g = 0f; var b = 0f
            for (k in -radius..radius) {
                val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                val q = kernel[k + radius]
                a += ((p ushr 24) and 255) * q; r += ((p ushr 16) and 255) * q
                g += ((p ushr 8) and 255) * q; b += (p and 255) * q
            }
            dst[y * w + x] = (a.toInt().coerceIn(0,255) shl 24) or (r.toInt().coerceIn(0,255) shl 16) or (g.toInt().coerceIn(0,255) shl 8) or b.toInt().coerceIn(0,255)
        }
        return android.graphics.Bitmap.createBitmap(dst, w, h, android.graphics.Bitmap.Config.ARGB_8888)
    }

    // Fast deterministic per-pixel white-noise source; coarse Gaussian fields above
    // provide the correlated component. Hashing avoids allocating full-frame noise planes.
    private fun uniformNoise(x: Int, y: Int, seed: Long): Float {
        var z = seed xor (x.toLong() * -7046029254386353131L) xor (y.toLong() * -4658895280553007687L)
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        z = z xor (z ushr 31)
        return ((z ushr 40).toInt() / 8388607.5f) - 1f
    }

    private fun srgbToLinear(v: Float): Float = if (v <= 0.04045f) v / 12.92f else Math.pow(((v + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    private fun linearToSrgb(v: Float): Float = if (v <= 0.0031308f) v * 12.92f else (1.055 * Math.pow(v.toDouble(), 1.0 / 2.4) - 0.055).toFloat()

    private class NoiseField(width: Int, height: Int, cell: Float, seed: Long) {
        private val step = cell.coerceAtLeast(0.5f)
        private val cols = (kotlin.math.ceil(width / step.toDouble()).toInt() + 2).coerceAtLeast(2)
        private val rows = (kotlin.math.ceil(height / step.toDouble()).toInt() + 2).coerceAtLeast(2)
        private val values = FloatArray(cols * rows)
        init {
            var s = seed
            for (i in values.indices) {
                s += -7046029254386353131L
                var z = s
                z = (z xor (z ushr 30)) * -4658895280553007687L
                z = (z xor (z ushr 27)) * -7723592293110705685L
                z = z xor (z ushr 31)
                val u1 = (((z ushr 11).toDouble() + 1.0) / (1L shl 53).toDouble()).coerceIn(1e-9, 1.0)
                s += -7046029254386353131L
                var z2 = s
                z2 = (z2 xor (z2 ushr 30)) * -4658895280553007687L
                z2 = (z2 xor (z2 ushr 27)) * -7723592293110705685L
                z2 = z2 xor (z2 ushr 31)
                val u2 = ((z2 ushr 11).toDouble() / (1L shl 53).toDouble()).coerceIn(0.0, 1.0)
                values[i] = (kotlin.math.sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)).toFloat().coerceIn(-3.5f, 3.5f)
            }
        }
        fun sample(px: Int, py: Int): Float {
            val gx = px / step
            val gy = py / step
            val x0 = gx.toInt().coerceIn(0, cols - 2)
            val y0 = gy.toInt().coerceIn(0, rows - 2)
            val tx = (gx - x0).coerceIn(0f, 1f)
            val ty = (gy - y0).coerceIn(0f, 1f)
            val a = values[y0 * cols + x0]
            val b = values[y0 * cols + x0 + 1]
            val c = values[(y0 + 1) * cols + x0]
            val d = values[(y0 + 1) * cols + x0 + 1]
            val top = a + (b - a) * tx
            val bottom = c + (d - c) * tx
            return top + (bottom - top) * ty
        }
    }
}
