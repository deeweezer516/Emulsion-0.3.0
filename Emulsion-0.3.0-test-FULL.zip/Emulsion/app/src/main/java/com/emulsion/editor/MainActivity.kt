package com.emulsion.editor

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EmulsionScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EmulsionScreen() {
    val context = LocalContext.current
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var settings by remember { mutableStateOf(GrainSettings()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Открой фотографию, чтобы начать") }
    var compareOriginal by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            status = "Загружаем фотографию…"
            (context as? ComponentActivity)?.lifecycleScope?.launch {
                val loaded = withContext(Dispatchers.IO) {
                    val src = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(src) { decoder, _, _ -> decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE }
                }
                original = loaded
                status = "${loaded.width} × ${loaded.height} px · оригинал загружен"
            }
        }
    }

    LaunchedEffect(original, settings) {
        val src = original
        if (src != null) {
            busy = true
            delay(140) // coalesce rapid slider movements before rendering
            val scale = minOf(1f, 1400f / maxOf(src.width, src.height))
            val small = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true) else src
            val rendered = withContext(Dispatchers.Default) { GrainRenderer.render(small, settings) }
            preview = rendered
            busy = false
            status = "${src.width} × ${src.height} px · зерно рассчитано для предпросмотра"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFC7A77A), background = Color(0xFF101010), surface = Color(0xFF1B1B1B),
        onBackground = Color(0xFFEDE9E2), onSurface = Color(0xFFEDE9E2)
    )) {
        Scaffold(containerColor = Color(0xFF101010), topBar = {
            TopAppBar(title = {
                Column {
                    Text("EMULSION", fontWeight = FontWeight.Bold, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
                    Text("STOCHASTIC FILM GRAIN LAB", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB4A58F))
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF101010)))
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 10.dp)) {
                // Pinned preview: only the controls below this region scroll.
                Box(Modifier.fillMaxWidth().heightIn(min = 170.dp, max = 290.dp).background(Color(0xFF202020), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    val shown = if (compareOriginal) original else preview
                    if (shown != null) Image(shown.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 290.dp), contentScale = ContentScale.Fit)
                    else Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("EMULSION", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF6D6255), fontWeight = FontWeight.Light)
                        Text("Ваше изображение появится здесь", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Открыть фото") }
                    OutlinedButton(onClick = { compareOriginal = !compareOriginal }, enabled = original != null, modifier = Modifier.weight(1f)) { Text(if (compareOriginal) "Показать обработку" else "Оригинал") }
                }
                Text(status, style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 5.dp))
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFFC7A77A))
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    HorizontalDivider(color = Color(0xFF333333))
                    Text("ЭМУЛЬСИЯ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    var formatExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = formatExpanded, onExpandedChange = { formatExpanded = it }) {
                        OutlinedTextField(value = settings.format.label, onValueChange = {}, readOnly = true, label = { Text("Формат негатива") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(formatExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = formatExpanded, onDismissRequest = { formatExpanded = false }) {
                            FilmFormat.entries.forEach { f -> DropdownMenuItem(text = { Text(f.label) }, onClick = { settings = settings.copy(format = f); formatExpanded = false }) }
                        }
                    }
                    var modelExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = modelExpanded, onExpandedChange = { modelExpanded = it }) {
                        OutlinedTextField(value = settings.model.label, onValueChange = {}, readOnly = true, label = { Text("Математическая модель") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(modelExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = modelExpanded, onDismissRequest = { modelExpanded = false }) {
                            GrainModelMode.entries.forEach { m -> DropdownMenuItem(text = { Text(m.label) }, onClick = { settings = settings.copy(model = m); modelExpanded = false }) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Монохром", style = MaterialTheme.typography.bodyMedium)
                            Text("Перевести фотографию в чёрно-белый режим", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Switch(checked = settings.blackAndWhite, onCheckedChange = { settings = settings.copy(blackAndWhite = it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = settings.monochrome, onCheckedChange = { settings = settings.copy(monochrome = it) })
                        Column {
                            Text("Нейтральное зерно")
                            Text("Общая структура шума для RGB-каналов", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                    SettingSlider("Количество зерна", settings.amount, 0f..1f, "${(settings.amount * 100).toInt()}") { settings = settings.copy(amount = it) }
                    SettingSlider("Диаметр частиц", settings.grainDiameterMicrons, 3f..30f, "${settings.grainDiameterMicrons.toInt()} мкм") { settings = settings.copy(grainDiameterMicrons = it) }
                    SettingSlider("Разброс размеров", settings.sizeSpread, 0f..1f, "${(settings.sizeSpread * 100).toInt()}") { settings = settings.copy(sizeSpread = it) }
                    SettingSlider("Группировка", settings.clumping, 0f..1f, "${(settings.clumping * 100).toInt()}") { settings = settings.copy(clumping = it) }
                    SettingSlider("Зависимость от тональности", settings.toneDependence, 0f..1f, "${(settings.toneDependence * 100).toInt()}") { settings = settings.copy(toneDependence = it) }
                    SettingSlider("Цветность зерна", settings.chroma, 0f..1f, "${(settings.chroma * 100).toInt()}") { settings = settings.copy(chroma = it) }
                    SettingSlider("Отклик в тенях", settings.shadowResponse, 0f..1f, "${(settings.shadowResponse * 100).toInt()}%") { settings = settings.copy(shadowResponse = it) }
                    SettingSlider("Отклик в светах", settings.highlightResponse, 0f..1f, "${(settings.highlightResponse * 100).toInt()}%") { settings = settings.copy(highlightResponse = it) }
                    SettingSlider("Винтаж · мягкость изображения", settings.vintage, 0f..1f, "${(settings.vintage * 100).toInt()}%") { settings = settings.copy(vintage = it) }
                    Text("«Винтаж» применяет мягкое гауссово размытие после добавления зерна: смягчаются и детали фотографии, и само зерно. Это художественная настройка, а не измеренная характеристика конкретной плёнки.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { settings = settings.copy(seed = settings.seed + 1L) }, modifier = Modifier.weight(1f)) { Text("Новое зерно") }
                        OutlinedButton(onClick = { settings = GrainSettings() }, modifier = Modifier.weight(1f)) { Text("Сбросить") }
                        Button(onClick = {
                            val src = original ?: return@Button
                            busy = true
                            status = "Рендер полного разрешения…"
                            (context as? ComponentActivity)?.lifecycleScope?.launch {
                                val result = withContext(Dispatchers.Default) { GrainRenderer.render(src, settings) }
                                val saved = withContext(Dispatchers.IO) { saveBitmap(context, result) }
                                busy = false
                                status = if (saved) "Сохранено в Pictures/Emulsion" else "Не удалось сохранить изображение"
                            }
                        }, enabled = original != null && !busy, modifier = Modifier.weight(1f)) { Text("Экспорт JPG") }
                    }
                    Text("Тестовая сборка 0.3 · модели экспериментальные, профили плёнок не откалиброваны. «Винтаж» — управляемое гауссово смягчение, а не физическая модель объектива.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, valueLabel: String, onChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(valueLabel, style = MaterialTheme.typography.labelMedium, color = Color(0xFFC7A77A))
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = Color(0xFFC7A77A), activeTrackColor = Color(0xFFC7A77A)))
    }
}

private fun saveBitmap(context: android.content.Context, bitmap: Bitmap): Boolean {
    return try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Emulsion_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Emulsion")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        val stream = context.contentResolver.openOutputStream(uri) ?: return false
        stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it) }
    } catch (_: Exception) { false }
}
