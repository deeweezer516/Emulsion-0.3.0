# Emulsion — Android grain editor + research bench (0.4.0-test)

Offline Android editor prototype plus the complete research material carried forward from Research Bench 0.9.

## Android test app
- Import an existing image through Android Photo Picker.
- Preview render capped at 1400 px on the long edge; export renders at source dimensions.
- Controls: grain amount, estimated particle diameter, size spread, clumping, tone response, chroma, shadow/highlight response, assumed negative format, neutral monochrome grain, black-and-white photo mode, Vintage softness, deterministic seed and new-seed action.
- The photo preview is pinned above the scrollable controls, so it remains visible while editing.
- **Vintage** applies a separable Gaussian low-pass after grain rendering, softening both image detail and grain. It is a controllable aesthetic effect, not a calibrated lens/film characteristic.
- **Monochrome** converts the source image to grayscale before grain is applied. The separate neutral-grain option only controls channel correlation and does not itself remove image color.
- Two selectable render modes:
  - **Correlated field** — multiscale correlated stochastic field; current default.
  - **Particle field · experimental** — thresholded correlated field intended only as a visual experiment. It is NOT the Poisson Boolean disk model in the Python bench and does not claim to simulate silver-halide crystals.
- JPEG export to `Pictures/Emulsion`.

## Changes in 0.4.0-test
- Fixed the preview at the top of the screen while the settings area scrolls independently.
- Added a Gaussian softness control named “Винтаж”.
- Added a true black-and-white image mode, distinct from neutral/monochrome grain.

## Added experimental image effects in 0.4.0-test
- Directional motion blur with angle control.
- Radial edge softness (stronger toward frame edges).
- Highlight-thresholded red halation with blur radius.
- Radial RGB channel displacement as a chromatic-aberration approximation.
- Fade / black lift / desaturation / highlight compression tone controls.
- Emulsion scattering approximation (low-frequency glow blend).
- Bleach-bypass approximation (contrast and desaturation).
- Local adjacency / unsharp-mask-like edge response.
- Optional grain-to-format size scaling, grain contour smoothing, and a white matte border.

These are active image-processing operations in the Android render path and affect both preview and exported output. Several are visual approximations, not calibrated physical models: edge softness, halation, scattering, chromatic aberration, fade, bleach bypass and adjacency. Motion blur is a directional image-space convolution. The matte is a simple fixed white border, not a full paper-print simulator.

## Scientific status — read before interpreting results
No named-film profile is calibrated. No verified physical scan dataset with known stock, development, scanner optical resolution, scanner linearity and reference patches is included. Consequently, UI parameters are artistic/model controls, not physical measurements. The diameter-to-pixel conversion is only a rough format-based scale estimate; it is not a validated grain-size measurement.

The Android renderer currently uses multiscale random fields and signal-dependent variance. The experimental particle mode is a thresholded field, not a true particle geometry simulator. The research-only Python modules include:
- empirical spatial statistics, autocorrelation and radial/full 2-D PSD diagnostics;
- scanner dark/clear and base-plus-fog calibration path for suitable linear grayscale scans;
- RGB channel covariance diagnostics (not automatic scanner-noise removal);
- independent PSD-controlled spectral Gaussian-field model and fitter;
- inhomogeneous Boolean/Poisson particle model with radius distributions and observation blur;
- synthetic tests and calibration/sample metadata protocols.

These research models are not all ported into Android. In particular, the Python Boolean model and spectral fitter remain research tools. Synthetic self-tests validate software behavior, not physical film fidelity. Do not describe this build as a Tri-X, HP5 or other stock emulation.

## Build Android APK
Open the `Emulsion` directory in Android Studio with JDK 17 and Android SDK Platform 35. Or use the included GitHub Actions workflow at `.github/workflows/android.yml`.

**GitHub repository layout:** extract the contents of this `Emulsion/` directory into the repository root (so `.github/workflows/android.yml`, `settings.gradle.kts`, `build.gradle.kts` and `app/` are directly at repository root). Merely uploading this ZIP as a file will not trigger the workflow inside it. Workflow builds `app/build/outputs/apk/debug/app-debug.apk`.

## Research bench
See `research/README.md` for installation, CLI commands, data semantics and test scope. Main references:
- `research/METHODS_AND_SOURCES.md`
- `research/CALIBRATION_PROTOCOL.md`
- `research/BOOLEAN_MODEL_NOTES.md`
- `research/RESEARCH_PLAN.md`
- `research/EXTERNAL_PROJECT_AUDIT.md`
- `research/PROGRESS_2026-11-08*.md`

## Known Android limitations
- CPU rendering; large images may be slow and memory-intensive.
- Preview is downscaled, export is full resolution; preview and export may differ in texture scale.
- JPEG-only output, no RAW/TIFF/16-bit pipeline, ICC management or metadata preservation.
- Slider updates are debounced but rendering still occurs on a coroutine dispatched to the default pool; this is a prototype, not a performance-optimized production editor.
- No undo/history, crop, masks, presets or named-film profiles.
