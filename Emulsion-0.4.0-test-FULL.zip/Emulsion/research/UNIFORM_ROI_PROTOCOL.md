# Uniform-exposure ROI protocol (Research Bench 0.7)

## Purpose

Estimate scan-domain noise statistics from a uniformly exposed film area while
keeping the scanner calibration assumptions explicit. The tool divides a
large ROI into non-overlapping tiles, estimates tile RMS after planar detrending,
and bootstraps tiles to show between-tile sampling variation.

This is **not** an ISO 10505 measurement and does not isolate intrinsic emulsion
noise from scanner noise or scanner MTF.

## Required inputs

1. A grayscale master scan (preferably 16-bit TIFF) with no sharpening,
   denoising, dust removal, automatic contrast, resizing or local corrections.
2. A uniform film area with known location and enough pixels for at least four
   complete tiles.
3. A calibrated physical sampling rate in pixels/mm measured from the actual
   scan geometry. TIFF DPI metadata alone is not accepted as proof of optical
   sampling because it may describe an output setting rather than film scale.
4. Scanner dark reference, clear reference, and base+fog reference acquired
   with the same scanner settings and scan pipeline.
5. Evidence that scanner values are proportional to transmitted light after
   the chosen transfer decoding. The script's dark/clear transform is affine;
   it cannot linearize an unknown nonlinear scanner response.

## Command

```bash
python research/analyze_uniform_roi.py scan.tif \
  --roi 1200 900 2048 2048 \
  --dark 0.002 --clear 0.985 --base 0.731 \
  --px-per-mm 2400 \
  --tile-px 256 --aperture-um 48 \
  --bootstrap 5000 --out research/results/tri_x_D08
```

The numbers above are placeholders, not recommended calibration values.
Measure dark, clear and base+fog references for the actual scanner session.

## Outputs

- JSON: full provenance, assumptions, limitations, tile results and bootstrap
  intervals.
- CSV: one row per non-overlapping tile.
- `scan_domain_tile_rms_*`: standard deviation of calibrated net projection
  density residuals after planar detrending.
- `digital_aperture_equivalent_*`: RMS after convolution with a sampled circular
  aperture of the specified diameter. This is a geometric digital-aperture
  approximation, not the complete ISO microdensitometer transfer function.
- Bootstrap interval: resampling tiles as units. It captures observed
  tile-to-tile sampling variability only; it does not include calibration,
  scanner MTF, batch, development, or instrument uncertainty.

## Interpretation rules

- Do not call these values “intrinsic film RMS” or “ISO RMS”.
- Do not subtract scanner noise unless independently measured under matching
  conditions and propagated through the scanner MTF / calibration chain.
- A single density level cannot establish a density-dependent granularity curve.
- A single physical sample cannot establish a stock-wide profile.
- Retain the original scan and all calibration references alongside outputs.
- Record film stock/version, emulsion batch if known, format, exposure, EI,
  developer, dilution, time, temperature, agitation, scanner, bit depth, scan
  mode, optical sampling, and any software processing.

## Synthetic validation

`python research/test_uniform_roi.py` creates a synthetic 16-bit scan from a
known flat density plus Gaussian noise, then checks density recovery, tile RMS
confidence interval ordering, and PSD/Parseval consistency. This validates
software arithmetic only; it is not evidence about any film stock.
