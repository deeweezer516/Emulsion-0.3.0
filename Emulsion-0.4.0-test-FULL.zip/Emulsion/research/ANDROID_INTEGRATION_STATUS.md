# Android integration status — 0.2.0-test

This file distinguishes what is actually integrated from what remains in the research bench.

## Integrated in Android
- Multiscale correlated random field (fine hash noise + interpolated Gaussian fields at two coarser scales).
- Signal-dependent variance proxy in linear-light RGB processing.
- Partially shared versus channel-independent noise controlled by chroma.
- Approximate format-based spatial scale control.
- Monochrome shared-noise option.
- Shadow/highlight response controls.
- Experimental thresholded-field mode, explicitly not presented as the physical Boolean model.
- Deterministic seed and seed increment control.

## Research-only (not integrated in Android)
- Poisson Boolean disks / log-normal particle radii / overlap and observation blur.
- Empirical PSD fitting and spectral Gaussian field synthesis.
- TIFF measurement pipeline, calibrated projection-density path, aperture diagnostic, ROI diagnostics and RGB common-mode analysis.

## Why the models are kept separate
The research models operate on measured scan statistics and/or explicit particle geometry. A direct port into the current per-pixel Android renderer without matching units, boundary handling, memory/performance design and physical calibration would imply accuracy that has not been demonstrated. The experimental Android mode is therefore labelled as an image-making approximation.

## Next validation gate
Acquire minimally processed, high-resolution uniform patches from a known film stock and development, with scanner model, true optical dpi, bit depth, scan mode, channel/transfer behavior, exposure and processing metadata. Measure scanner dark/clear and film base-plus-fog references. Only then fit spatial PSD, variance-versus-tone and cross-channel covariance; retain hold-out patches for independent validation.
