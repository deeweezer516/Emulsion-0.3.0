# External reference audit: Grainifier (candidate, not yet validated by us)

Repository: https://github.com/grainifier/grainifier

The repository README (retrieved 2026-11-08) claims:
- measured B&W profiles for Ilford HP5 Plus EI 1600 and Kodak Double-X 5222;
- a Nikon Coolscan V ED / VueScan RAW DNG workflow at 4000 dpi;
- 114 single-pass HP5 frames and 124 single-pass Double-X frames, plus larger mixed-pass datasets;
- per-density-bin variance, skewness, autocorrelation and 2D NPS;
- scanner-noise estimation using inter-channel covariance / a "three-cornered hat" argument;
- a public CC BY 4.0 frame-statistics dataset identified as DOI 10.5281/zenodo.22170495;
- MIT software license.

These are **author-reported claims from the README**, not independent measurements performed by Emulsion. Search results expose the README, but we have not yet inspected the implementation, the underlying profile JSON, the research notes, the tests, or the Zenodo record. The DOI did not yield an independently readable record in this review session. Therefore no Grainifier profile values have been copied into Emulsion.

## Why this project is promising

Its central design is aligned with our measurement goal: work in negative-density/transmittance space, model signal-dependent noise, retain a measured 2D spectrum, and account for scanner sampling/blur. The README's described 4000 dpi sampling pitch (25.4 mm / 4000 = 6.35 µm) is internally consistent.

## Questions to audit before reuse or benchmarking

1. Does the DNG reader truly preserve linear scanner measurements and black/white levels, or apply any hidden normalization?
2. Is the three-channel covariance estimator valid for the particular scanner? It relies on a shared silver-grain component and channel-specific scanner noise; correlated sensor/readout noise, channel crosstalk, CFA/demosaicing or spectral weighting can bias the separation.
3. How are image structure, edge contamination, low-frequency illumination gradients and local subject texture rejected?
4. Does the 2D NPS estimator include window normalization, detrending and physical frequency units correctly?
5. Are single-pass and multi-pass samples kept separate? Does the claimed ~0.5 px blur correspond to a measured MTF comparison?
6. Are per-roll results consistent, and are validation frames genuinely held out from fitting?
7. Can the published summary dataset reproduce the profile JSON exactly, and can the software version/commit be pinned?
8. Does the renderer reproduce only the same statistics it fitted (closed-loop), or also independently predict unseen real scans? Closed-loop self-consistency alone is not external validation.

## Emulsion decision

Use Grainifier as a high-value comparator and possible source of openly licensed *summary statistics* only after the checks above. Do not silently copy its profiles, claim its measurements as our own, or assume its HP5 EI 1600 profile represents box-speed HP5. The project-specific stock/process/scanner combination matters.

## Findings from the public README review (2026-11-08)

The public README is unusually specific and gives a reproducible high-level pipeline: negative-density domain, per-density noise amplitude and skewness, 2-D NPS, autocorrelation, scan-curve estimation, physical sampling pitch, and separate single-pass versus multi-pass profiles. It reports that the bundled HP5+ profile is EI 1600 (not box speed), and that the Double-X profile is EI 250. Those distinctions matter: neither profile can be relabelled as a generic stock profile or a box-speed profile.

The README further says the public 659 MB CC BY 4.0 dataset contains per-patch statistics and per-bin spectra for 728 frames, not the original scans. If accurate, this permits re-aggregation and consistency checks but not independent visual inspection of the negatives or re-measurement from source pixels. The bundled profile JSONs and README claims remain author-supplied evidence until their files, metadata, software commit and Zenodo record are inspected and reproduced.

### Specific caveats for Emulsion

- The Wikimedia Tri-X candidates are 16-bit **grayscale PNGs**, not linear raw RGB scanner data. Because they are grayscale, they cannot support Grainifier's described inter-channel covariance / three-cornered-hat scanner-noise separation. They can support exploratory scan-domain spatial analysis only.
- The Commons author reports GIMP rotation and luminance normalization to approximately CIELAB middle gray. A second file has a D65 Linear Grayscale profile embedded, but the normalization still means absolute density and the original mean level cannot be recovered from the published file alone.
- The image page reports 5,642 × 3,671 px. The description says Nikon Coolscan V ED, but it does not supply a complete calibration record (scan mode, single/multi-pass, sharpening, grain reduction, ICE, exact crop, processing settings). Do not infer precise µm grain scale from the page's nominal DPI metadata; the displayed dpc metadata and scan dimensions do not by themselves establish optical sampling.
- Grainifier's stated separation of common silver-grain variance from channel-specific scanner noise depends on its channel-noise covariance assumptions. Those assumptions need scanner-specific validation; channel crosstalk, shared illumination/readout fluctuations or spectral/MTF differences can bias the estimate.
- Its closed-loop renderer/profile agreement is a useful software consistency test but is not, by itself, an independent validation against held-out physical negatives. The README also reports a real HP5 comparison within 10–25%; this needs inspection of the comparison protocol and independent replication before treating it as a general accuracy guarantee.

### Decision

Adopt Grainifier's *research architecture* as the leading comparator, not its parameter values as ground truth. In particular, implement density-dependent statistics and preserve full 2-D spectra in Emulsion's bench. Do not import its HP5 EI 1600 profile as HP5 ISO 400, and do not call a scan-domain profile a stock-only emulsion profile: film, EI, developer, processing, scanner, scan mode and inversion pipeline all contribute.


## Follow-up source review (2026-11-08)

The current public README search extract makes the pipeline more concrete: it says statistics are measured on scanner transmittance before inversion/sharpening; 32-pixel plane-detrended patches are used; R/G/B covariances are used to estimate common silver-grain variance versus channel-specific scanner noise; a low-frequency power fraction rejects textured scene patches; green-channel NPS is accumulated by density bin; and single-pass versus multi-pass profiles are kept separate. This is a strong design reference, but all of these remain README-described implementation claims until the actual code and data are inspected and reproduced.

The three-channel covariance decomposition is not universally valid by definition. It relies on the shared grain contribution being common across channels and scanner noise being sufficiently channel-specific/uncorrelated. Cross-channel electronics, shared illumination fluctuation, spectral response, channel resampling, and demosaicing can violate that assumption. Emulsion v0.4 therefore reports the covariance matrix but deliberately does not subtract a scanner-noise estimate.

The public repo identifies the software as MIT and the profiles/dataset as CC BY 4.0; the IPOL 2017 paper's source page lists a different license (article CC-BY-NC-SA; code GPL-3.0-or-later). Treat each asset's license independently. No Grainifier code, profiles or dataset values have been copied into Emulsion v0.4.
