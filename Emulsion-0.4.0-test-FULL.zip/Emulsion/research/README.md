# Emulsion Research Bench v0.6

A reproducible first-pass image-texture measurement harness. It preserves integer TIFF precision, defaults to native scan values (no guessed transfer curve), measures RGB channels independently, reports cross-channel covariance/correlation, records basic TIFF metadata, includes synthetic self-tests, planar detrending, Parseval checks, full 2-D spatial diagnostics, optional calibrated net projection-density conversion and a sampled circular-aperture diagnostic. It does **not** claim to identify physical silver grains from arbitrary JPEGs or to implement ISO 10505.

## Install

```bash
python -m pip install -r research/requirements.txt
```

## Generate a 16-bit test target

```bash
python research/bench.py target --out research/data/emulsion_test_target.tif --size 2048 --bit-depth 16
```

## Analyze an image

```bash
python research/bench.py analyze scan.tif --out research/results/sample --patch-width 256 --px-per-mm 100
```

For a manually selected ROI:

```bash
python research/bench.py analyze scan.tif --out research/results/sample --roi 500 500 512 512 --px-per-mm 100
```

`--transfer native` is the default and preserves stored sample values after integer-range normalization. Use `--transfer linear` only when the scan values are known to be linear transmittance; use `--transfer srgb` only for a known sRGB-encoded image. The tool does not apply embedded ICC profiles or infer scanner linearity. Native RGB channels are analyzed separately; do not interpret channel correlation as a validated scanner-noise subtraction without validating the scanner-specific assumptions.

## Run synthetic validation

```bash
python research/bench.py selftest --out research/results/selftest_v2
```

The self-test checks white noise, spatially correlated noise and a constant field. It is not validation against real photographic film.

## Outputs

- `metrics.json`: detailed metrics and provenance.
- `summary.csv`: concise per-ROI results.
- `spectral_diagnostics.png`: radial autocorrelation and radial periodogram.
- `<roi>_spatial.npz`: full 2-D autocorrelation and periodogram for each channel, with spatial-frequency axes.
- RGB inputs: per-channel statistics and residual cross-channel covariance/correlation; no automatic luma collapse for measurement.
- Metrics: raw ROI mean, detrended variance/RMS, approximate 1/e correlation length, radial autocorrelation and radial PSD.
- Detrending: `--detrend plane` (default), `constant`, or `none`.
- Optional density path: affine dark/clear scanner calibration for already-linear transmission scans, then net projection density relative to a measured base-plus-fog reference. This does not convert projection density to ISO diffuse density.
- Optional 48 µm circular-aperture diagnostic: applies a sampled geometric disk average before RMS calculation. This models only the aperture geometry, not the ISO microdensitometer optics, spectral conditions, diffuse conversion factor, instrument-noise correction or uncertainty estimator.
- With `--px-per-mm`, PSD frequency is represented in cycles/mm and power density in signal²·mm².

**Important:** bench RMS is in the selected scan signal domain. It is not the manufacturer's diffuse RMS granularity value (e.g. Kodak's reported 17) and must not be compared directly with it. See `METHODS_AND_SOURCES.md` for the source audit, limitations and physical-sample protocol.

## Validation status

Twenty-seven unit tests plus two standalone synthetic integration checks cover 16-bit TIFF precision, constant and correlated fields, planar detrending, density conversion, scanner dark/clear calibration, sampled aperture geometry, PSD frequency scaling, Parseval consistency, full 2-D export, uniform-ROI density recovery, tile-bootstrap interval generation and two-scale PSD parameter recovery. These validate software behavior on synthetic data, not the physical accuracy of any film profile.

## Additional research notes

- `METHODS_AND_SOURCES.md`: measurement semantics, source audit and physical-sample protocol.
- `EXTERNAL_PROJECT_AUDIT.md`: independent review checklist for the promising Grainifier project; its profile values are not imported.
- v0.4 uses native sample values by default because a scanner TIFF is not guaranteed to be sRGB or linear-light encoded.
- `candidate_samples.json`: candidate CC0 Tri-X scan references, with explicit processing caveats.


## Calibration documents

- `CALIBRATION_PROTOCOL.md`: acquisition and acceptance gates for a defensible B&W film profile.
- `film_profile_template.json`: explicit metadata/provenance schema; it is intentionally empty and must not be mistaken for a measured profile.


## v0.5: calibrated projection-density and aperture diagnostic

Example for a grayscale scan known to contain linear transmittance values normalized to [0, 1]:

```bash
python research/bench.py analyze scan_linear.tif \
  --roi 500 500 512 512 \
  --px-per-mm 157.48 \
  --transfer native \
  --density-calibration 0.015 0.985 0.802 \
  --aperture-um 48 \
  --out research/results/tri_x_roi
```

The three calibration values are normalized scan signals for: (1) scanner dark reference, (2) clear transmission reference, and (3) unexposed processed film base-plus-fog. They must be measured in the same scan mode and channel, with a linear scanner signal. The analyzer applies an affine dark/clear calibration and computes `D_net,projection = -log10(T / T_base+fog)`. It does not infer scanner linearity from the TIFF bit depth or metadata.

The optional aperture diagnostic uses a supersampled, area-normalized circular kernel with the requested physical diameter. At 4000 true optical dpi, 48 µm spans approximately 7.56 scan pixels. The reported `aperture_rms_x1000` remains in **net projection-density units**. ISO 10505 additionally specifies the microdensitometer optical geometry, spectral conditions, conversion to diffuse density, instrument-noise correction, estimator and confidence intervals. Therefore this digital value is explicitly **not** an ISO 10505 result and must not be compared directly with Kodak's diffuse RMS figure 17.

The current CLI density-calibration path accepts grayscale only. RGB needs separate per-channel scanner calibration and a validated spectral/density model; cross-channel covariance alone is not sufficient to isolate scanner noise.


## Experimental stochastic model (v0.6)

A separate, research-only Boolean grain renderer is included in `boolean_grain_model.py`. It follows the mathematical structure of the Newson et al. inhomogeneous Boolean model: Poisson-distributed grain centers, constant or log-normal radii, intensity tied to calibrated negative density, and an explicit observation blur. It is deliberately separate from the Android application.

Example:

```bash
python research/boolean_grain_model.py \
  --density calibrated_net_projection_density.npy \
  --out research/results/boolean_trial.tif \
  --px-per-mm 157.48 \
  --mean-radius-um 2.5 \
  --radius-cv 0.35 \
  --blur-sigma-um 0.5 \
  --seed 42
```

The radius and blur values in this example are arbitrary test parameters, **not Tri-X measurements**. The input must be a calibrated net projection-density array; arbitrary sRGB images are not valid inputs. The output TIFF/NPY contains simulated negative transmittance. Read `BOOLEAN_MODEL_NOTES.md` before interpreting it. This renderer is a mathematical prototype only; it is not a physically complete emulsion model and has not been integrated into Android.

### Boolean model validation reference

`boolean_grain_model.py` includes a homogeneous fixed-radius analytic covariance reference. Use it to validate the *unfiltered continuous model* first; do not compare it directly to scanner measurements without accounting for raster aperture, observation blur and scanner MTF. The model's documented limitation for bright/white grain structures is important: it is not a universal B&W film model.

## v0.6: spectral-statistical synthesis baseline

` spectral_grain_model.py` (without the leading space) provides an empirical Gaussian random-field renderer with a two-scale Gaussian-mixture PSD and a user-defined density-dependent residual standard deviation curve. `fit_spectral_profile.py` fits a radial PSD shape from a bench spatial NPZ export. These tools support model comparison and eventual measured-profile fitting; their parameters are not physical crystal sizes or film-stock profiles.

Run the synthetic comparison:

```bash
python compare_models.py
```

Fit a spectral shape from a measured bench export (only when it contains physical frequency axes):

```bash
python fit_spectral_profile.py --npz results/your_roi_spatial.npz --channel gray --out results/your_roi_spectral_fit.json
```

The spectral renderer is periodic at the ROI boundaries because it uses FFT synthesis. Do not use it as a production tiled renderer until overlap handling and seam tests are implemented. Do not interpret the Boolean binary coverage output as continuous optical density: zero-transmittance pixels map to infinite density.

## v0.7: uniform-ROI analysis with tile bootstrap

`analyze_uniform_roi.py` is the recommended next step when a genuinely uniform
film exposure and scanner calibration references are available. It requires
explicit dark, clear and base+fog references, cuts the selected ROI into
non-overlapping tiles, calculates tile-level density-domain statistics and
reports a bootstrap interval across tiles. It writes JSON and CSV.

```bash
python research/analyze_uniform_roi.py scan.tif \
  --roi 1200 900 2048 2048 \
  --dark 0.002 --clear 0.985 --base 0.731 \
  --px-per-mm 2400 --tile-px 256 --aperture-um 48 \
  --bootstrap 5000 --out research/results/tri_x_D08
```

The calibration values above are examples only. Measure them in the same
scanner mode; do not copy them. Read `UNIFORM_ROI_PROTOCOL.md` first. Its
bootstrap interval is between-tile variability, not a full metrological
uncertainty budget. The aperture result is a digital projection-density
approximation, not ISO 10505 intrinsic RMS granularity.

Run the new synthetic tests:

```bash
python research/test_uniform_roi.py
python research/test_spectral_fit.py
```

These validate numerical behavior using synthetic data only. They do not
calibrate Tri-X, HP5 or any other emulsion.

## v0.8 additions

- Spatial moving-block bootstrap for tile-level ROI uncertainty; IID bootstrap
  remains a diagnostic only.
- Neighboring-tile RMS correlation diagnostic.
- RGB common-mode covariance diagnostic in `rgb_common_mode.py`.
- See `RGB_COMMON_MODE_PROTOCOL.md` and `PROGRESS_2026-11-08_v08.md`.

Run all research tests with `python -m pytest -q` from this directory.
