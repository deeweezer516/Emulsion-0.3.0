# Calibration protocol: B&W film, scan-domain to film-domain

## Purpose

Build a stock/process/scanner-specific profile without confusing emulsion granularity with scanner noise, scene texture, inversion, tone curves, sharpening, resampling or multi-pass averaging.

## Acquisition requirements (preferred)

1. Use a calibration roll from one identified emulsion generation / batch. Record stock, format, expiry or date code, exposure index and exposure method.
2. Include evenly exposed uniform patches spanning several negative densities, not just one middle-gray patch. A sensitometric step wedge is preferred; record exposure steps and processing.
3. Record developer, dilution, temperature, time, agitation, lab/operator and push/pull process.
4. Scan as linear/raw transmission data before inversion. Preserve native bit depth and all original channels. Disable sharpening, grain reduction, automatic levels, local contrast, ICE/infrared cleaning and resampling. Prefer single-pass scans; keep multi-pass as a separate acquisition condition.
5. Record scanner model, software/version, scan mode, nominal DPI, calibrated pixel pitch, black/white levels, ICC profile and any processing. Repeat a subset to estimate scanner repeatability.
6. Capture clear film base-plus-fog and an unexposed/blank reference under the same scan setup if possible. These are needed to estimate net optical density from linear transmittance.

## Analysis protocol

1. Hash and preserve originals. Never overwrite them. Store all metadata in `film_profile_template.json`.
2. Inspect histograms, clipping, channel alignment, row/column banding, dust, scratches, edge contamination and illumination gradients. Reject contaminated ROIs with a logged reason.
3. Work in calibrated linear transmittance. For a matched base-plus-fog reference `T_b`, calculate net density `D = -log10(T/T_b)`. Do not apply this to normalized JPEG/PNG or unknown nonlinear scans.
4. Divide data into density bins (initially 0.1 D is a practical exploratory bin width, not a standard requirement). Keep per-frame and per-roll grouping; do not treat thousands of patches from one frame as independent rolls.
5. For each accepted ROI and channel, report mean density, detrended variance/RMS, skewness/kurtosis, 2-D NPS, directional and radial autocorrelation, low-frequency energy fraction and channel covariance. Retain raw and detrended results.
6. Characterize scanner noise independently where possible: repeated scans of the same stationary negative, blank/clear-base scans, and scanner dark/flat-field data. Cross-channel covariance can be diagnostic but is not automatically a valid noise subtraction.
7. Aggregate by stock + EI + developer/process + scanner + scan mode. Report per-roll spread and confidence intervals. Hold out complete frames or rolls for validation.
8. Compare the 48 µm RMS anchor only when the measurement geometry, density definition, spectral conditions and instrument correction are compatible with ISO 10505 / the manufacturer's stated method. Do not compare scan-pixel RMS directly to the manufacturer's RMS number.

## Acceptance gates

- **G0 — provenance:** stock, process, scanner and source file lineage recorded.
- **G1 — signal validity:** raw/linear transmittance and bit depth verified; no clipping or hidden tone processing.
- **G2 — density validity:** base-plus-fog reference and density conversion documented.
- **G3 — scanner validity:** sampling pitch and scanner noise/MTF characterized sufficiently for the intended claim.
- **G4 — statistical stability:** multiple ROIs, frames and preferably rolls; uncertainty reported.
- **G5 — held-out validation:** parameters fit on training scans predict statistics on independent scans.

Only after G0–G5 may the profile be labelled `measured_and_validated`. A profile that passes only image-statistics fitting must be labelled `scan_pipeline_profile`, not a stock-only emulsion profile.
