#!/usr/bin/env python3
"""Empirical, PSD-controlled grain/noise field model.

This is deliberately a statistical synthesis model, not a literal silver-halide
microstructure model. Parameters must be fitted to calibrated scan measurements.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from scipy.ndimage import gaussian_filter
import tifffile


def _validate_shape(shape):
    if len(shape) != 2 or min(shape) < 16:
        raise ValueError("shape must be 2D and each dimension >= 16")


def gaussian_mixture_psd(shape, px_per_mm, scales_um=(2.0, 8.0), weights=(0.7, 0.3), white_floor=0.0):
    """Return an isotropic 2-D PSD shape from Gaussian covariance components.

    Spatial scales are Gaussian covariance sigma values in micrometres. The
    returned PSD is normalized to unit mean over the discrete frequency grid.
    Frequency coordinates are cycles/mm; exponent uses sigma in mm.
    """
    _validate_shape(shape)
    px_per_mm = float(px_per_mm)
    scales = np.asarray(scales_um, dtype=float)
    w = np.asarray(weights, dtype=float)
    floor = float(white_floor)
    if not np.isfinite(px_per_mm) or px_per_mm <= 0: raise ValueError("px_per_mm must be > 0")
    if scales.ndim != 1 or len(scales) == 0 or np.any(~np.isfinite(scales)) or np.any(scales <= 0):
        raise ValueError("scales_um must contain positive finite values")
    if w.shape != scales.shape or np.any(~np.isfinite(w)) or np.any(w < 0) or w.sum() <= 0:
        raise ValueError("weights must be nonnegative, match scales, and have positive sum")
    if not np.isfinite(floor) or floor < 0: raise ValueError("white_floor must be >= 0")
    w = w / w.sum()
    fy = np.fft.fftfreq(shape[0], d=1.0 / px_per_mm)
    fx = np.fft.rfftfreq(shape[1], d=1.0 / px_per_mm)
    f2 = fy[:, None]**2 + fx[None, :]**2
    psd = np.full(f2.shape, floor, dtype=np.float64)
    for wi, su in zip(w, scales):
        sigma_mm = su / 1000.0
        # Fourier transform of Gaussian covariance exp(-r^2/(2 sigma^2)).
        psd += wi * np.exp(-2.0 * np.pi**2 * sigma_mm**2 * f2)
    mean = float(np.mean(psd))
    if mean <= 0: raise ValueError("PSD has zero power")
    return psd / mean


def synthesize_unit_field(shape, px_per_mm, scales_um=(2.0, 8.0), weights=(0.7, 0.3), white_floor=0.0, seed=1):
    """Generate a reproducible approximately unit-variance stationary Gaussian field."""
    psd = gaussian_mixture_psd(shape, px_per_mm, scales_um, weights, white_floor)
    rng = np.random.default_rng(seed)
    white = rng.standard_normal(shape)
    spectrum = np.fft.rfft2(white)
    field = np.fft.irfft2(spectrum * np.sqrt(psd), s=shape).real
    field -= field.mean()
    sd = field.std()
    if sd <= 0: raise RuntimeError("generated field has zero variance")
    field /= sd
    return field, psd


def density_sigma(net_density, density_knots, sigma_knots):
    """Piecewise-linear empirical sigma(D) curve; extrapolation is clamped."""
    d = np.asarray(net_density, dtype=np.float64)
    dk = np.asarray(density_knots, dtype=np.float64)
    sk = np.asarray(sigma_knots, dtype=np.float64)
    if dk.ndim != 1 or sk.shape != dk.shape or len(dk) < 2:
        raise ValueError("density and sigma knots must be 1D arrays of equal length >= 2")
    if np.any(~np.isfinite(dk)) or np.any(~np.isfinite(sk)) or np.any(sk < 0) or np.any(np.diff(dk) <= 0):
        raise ValueError("density knots must increase; sigma knots must be finite and >= 0")
    return np.interp(d, dk, sk, left=sk[0], right=sk[-1])


def render_spectral_density(net_density, px_per_mm, density_knots, sigma_knots,
                            scales_um=(2.0, 8.0), weights=(0.7, 0.3),
                            white_floor=0.0, seed=1):
    """Add empirical correlated Gaussian residuals in net-density domain.

    No clipping is applied: clipping biases the mean and changes the PSD.
    This routine does not simulate exposure, development, silver crystals,
    scanner MTF, or the conversion between diffuse and projection density.
    """
    d = np.asarray(net_density, dtype=np.float64)
    _validate_shape(d.shape)
    if np.any(~np.isfinite(d)) or np.any(d < 0): raise ValueError("net density must be finite and >= 0")
    field, psd = synthesize_unit_field(d.shape, px_per_mm, scales_um, weights, white_floor, seed)
    sig = density_sigma(d, density_knots, sigma_knots)
    residual = sig * field
    out = d + residual
    return {"density": out, "residual": residual, "unit_field": field,
            "psd_shape": psd, "diagnostics": {
                "model": "empirical Gaussian random field with Gaussian-mixture PSD",
                "seed": int(seed), "px_per_mm": float(px_per_mm),
                "scales_um": [float(x) for x in scales_um],
                "weights_normalized": (np.asarray(weights, dtype=float)/np.sum(weights)).tolist(),
                "white_floor": float(white_floor),
                "density_knots": [float(x) for x in density_knots],
                "sigma_knots": [float(x) for x in sigma_knots],
                "residual_std": float(residual.std()),
                "warning": "empirical statistical model; not physical grain and not calibrated to a film stock"
            }}


def fit_gaussian_mixture_psd(radial_frequency_cyc_mm, radial_psd, scales_bounds_um=(0.1, 100.0)):
    """Fit two Gaussian covariance scales plus white floor to radial PSD shape.

    Inputs must be a nonnegative radial PSD estimate. The fit is shape-only;
    absolute variance is estimated separately from the density residuals.
    """
    f = np.asarray(radial_frequency_cyc_mm, dtype=float)
    p = np.asarray(radial_psd, dtype=float)
    if f.ndim != 1 or p.shape != f.shape or len(f) < 8: raise ValueError("need >=8 paired radial samples")
    valid = np.isfinite(f) & np.isfinite(p) & (f >= 0) & (p >= 0)
    f, p = f[valid], p[valid]
    if len(f) < 8 or p.max() <= 0: raise ValueError("insufficient nonzero PSD data")
    p = p / p.mean()
    lo, hi = map(float, scales_bounds_um)
    if not (0 < lo < hi): raise ValueError("invalid scale bounds")
    # parameters: log(sigma1), log(sigma2), logit(weight1), log(white_floor)
    def unpack(x):
        s1, s2 = np.exp(x[0]), np.exp(x[1])
        w1 = 1/(1+np.exp(-x[2]))
        floor = np.exp(x[3])
        return s1, s2, w1, floor
    def model(x):
        s1, s2, w1, floor = unpack(x)
        raw = w1*np.exp(-2*np.pi**2*(s1/1000)**2*f**2) + (1-w1)*np.exp(-2*np.pi**2*(s2/1000)**2*f**2) + floor
        return raw / raw.mean()
    x0 = np.array([np.log(max(lo*2, 1)), np.log(min(hi/2, 10)), 0.0, np.log(0.02)])
    res = least_squares(lambda x: np.log(model(x)+1e-8)-np.log(p+1e-8), x0,
                        bounds=([np.log(lo), np.log(lo), -8, np.log(1e-8)],
                                [np.log(hi), np.log(hi), 8, np.log(10)]), max_nfev=5000)
    s1, s2, w1, floor = unpack(res.x)
    return {"scales_um": [float(s1), float(s2)], "weights": [float(w1), float(1-w1)],
            "white_floor": float(floor), "log_rmse": float(np.sqrt(np.mean(res.fun**2))),
            "success": bool(res.success), "warning": "shape-only fit; not a physical grain-size estimate"}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--density', required=True, help='2D .npy calibrated net density')
    ap.add_argument('--out', required=True, help='output TIFF')
    ap.add_argument('--px-per-mm', type=float, required=True)
    ap.add_argument('--seed', type=int, default=1)
    args=ap.parse_args()
    d=np.load(args.density)
    result=render_spectral_density(d,args.px_per_mm,[0,0.5,1,2],[0.0,0.01,0.015,0.01],seed=args.seed)
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    np.save(out.with_suffix('.npy'),result['density'].astype(np.float32))
    tifffile.imwrite(out.with_suffix('.tif'), result['density'].astype(np.float32), photometric='minisblack')
    out.with_suffix('.json').write_text(json.dumps(result['diagnostics'],indent=2))
    print(json.dumps(result['diagnostics'],indent=2))

if __name__=='__main__': main()
