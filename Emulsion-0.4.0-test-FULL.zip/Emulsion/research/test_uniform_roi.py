#!/usr/bin/env python3
"""Synthetic validation for analyze_uniform_roi; not a film calibration."""
import sys, tempfile
from pathlib import Path
import numpy as np
import tifffile
from analyze_uniform_roi import analyze_uniform_roi, _moving_block_bootstrap


def main():
    rng = np.random.default_rng(701)
    h = w = 512
    dark, clear, base = 0.02, 0.98, 0.78
    base_t = (base-dark)/(clear-dark)
    true_density = 0.72
    sigma = 0.012
    density = true_density + rng.normal(0, sigma, (h,w))
    trans = base_t * 10.0**(-density)
    scan = dark + (clear-dark)*trans
    # TIFF uint16 normalized to full-scale integer range.
    scan16 = np.round(np.clip(scan,0,1)*65535).astype(np.uint16)
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)/'synthetic_flat.tif'
        tifffile.imwrite(p, scan16, photometric='minisblack')
        got = analyze_uniform_roi(str(p), (0,0,w,h), dark, clear, base,
                                  px_per_mm=2000, tile_px=128, aperture_um=24,
                                  bootstrap=300, seed=19)
    assert got['tile_count'] == 16, got['tile_count']
    assert abs(got['results']['mean_net_projection_density']-true_density) < 2e-4
    lo, med, hi = got['results']['scan_domain_tile_rms_ci95_percentile']
    assert lo <= med <= hi
    assert 0.008 < med < 0.016, med
    assert got['results']['mean_parseval_relative_error'] < 1e-10
    assert got['sampling']['spatial_block_tiles'] == 2
    assert got['results']['scan_domain_tile_rms_ci95_spatial_block'][0] <= got['results']['scan_domain_tile_rms_ci95_spatial_block'][1] <= got['results']['scan_domain_tile_rms_ci95_spatial_block'][2]
    # Reproducibility and range check for spatial moving-block bootstrap.
    vals = np.arange(1, 17, dtype=float) / 100
    a = _moving_block_bootstrap(vals, (4,4), 2, 300, np.random.default_rng(9))
    b = _moving_block_bootstrap(vals, (4,4), 2, 300, np.random.default_rng(9))
    assert a == b and a[0] <= a[1] <= a[2]
    print('PASS: synthetic calibrated flat-field; density, spatial-block tile CI, deterministic bootstrap and PSD Parseval check')
    print({'tiles':got['tile_count'], 'density':got['results']['mean_net_projection_density'],
           'rms_ci95':got['results']['scan_domain_tile_rms_ci95_percentile']})

if __name__ == '__main__': main()
