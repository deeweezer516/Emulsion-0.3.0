# Measurement protocol and source audit (history through v0.6)

## What the numbers mean

Do not conflate three different quantities:

1. **RMS granularity** is an objective microdensity-fluctuation statistic for a uniformly exposed and processed film sample. ISO 10505:2009 defines intrinsic RMS granularity as fluctuations attributable to the distribution of developed image-forming centres. It distinguishes this from *graininess*, which is a perceptual/psychophysical quantity.
2. **Wiener/noise power spectrum (NPS/PSD)** describes how density-fluctuation power is distributed over spatial frequency. It is not interchangeable with one RMS number.
3. **Rendered graininess** is what a viewer sees after the complete negative/positive, optical, scanning, resizing, sharpening, display and viewing pipeline. It cannot be inferred from the emulsion alone.

ISO 10505:2009 covers monochrome silver-absorbing and colour dye-absorbing continuous-tone films on transparent support. The standard explicitly does not define the Wiener-spectrum measurement. It also requires attention to instrument noise, sample imperfections, density conversion, measurement geometry and uncertainty. Its reporting requirements include the aperture specification and confidence limits. Our image-analysis CLI is a research aid, **not an ISO-conformant microdensitometer**.

## Verified Kodak Tri-X 400 reference datum

Kodak publication F-4017 (September 2002), image-structure section, reports diffuse RMS granularity 17 for TRI-X Pan Film / TX and 16 for TRI-X Pan Professional / TXP/TXT. The measurement note specifies net diffuse density 1.0, a 48 µm aperture and 12× magnification.

Important qualification: Kodak explicitly says this image-structure data were generated on older versions of the films; it says granularity testing of old and new versions in several other developers suggests the data should also apply to the new versions. The data are based on HC-110 Dilution B at 20 °C to contrast index 0.56. The 7.5-minute small-tank / 30-second agitation recipe in that section is for legacy TRI-X Pan TX, not a guaranteed development recipe for every current 400TX batch. Treat 17 as a useful manufacturer reference anchor with a stated lineage, not as a batch-specific modern measurement.

## Verified Ilford HP5 Plus information

The official Ilford HP5 Plus product page describes the stock as fine-grain and lists multiple developers and development times. Its linked November 2018 technical data sheet was checked for the terms "RMS" and "granularity"; neither occurs in the extracted text. We therefore leave the quantitative RMS field blank. This is a statement about the accessed official sheet, not proof that no Ilford publication anywhere contains such a measurement.

## Why the scanner pipeline matters

A scan is not a transparent microscope. It includes scanner optics/MTF, sampling, detector noise, tonal response, sharpening, denoising, dust-removal processing, resampling and sometimes automatic inversion/contrast. A 16-bit file is not automatically raw or linear. For any serious comparison, preserve the master scan and record:
- scanner make/model and scan mode;
- optical sampling in pixels/mm (not merely interpolated DPI);
- bit depth and transfer/tone curve;
- sharpening, grain reduction, infrared dust removal, automatic contrast and resizing;
- negative/positive orientation and whether the file is a camera scan or lab scan;
- film stock, format, batch/emulsion code if known, exposure/EI, developer, dilution, time, temperature and agitation.

Historical note: v0.2 defaulted to sRGB conversion, which was later identified as unsafe for arbitrary scanner TIFFs. v0.4 supersedes that behavior: it defaults to `native` and requires explicit transfer selection. The reported RMS remains in the selected scan signal domain; it is **not** the Kodak diffuse RMS scale and must not be compared directly with Kodak's "17".

## v0.2 analysis implementation

- Input: grayscale or interleaved RGB(A), integer TIFF bit depth preserved; ordinary image files are loaded at their stored precision.
- Signal: sRGB-to-linear conversion by default; can be disabled for known-linear data.
- Flat ROI statistics: mean, variance and RMS of the selected signal.
- Autocorrelation: FFT correlation with overlap-count normalization; constant/zero-variance ROIs return no correlation length instead of a fabricated value.
- Spectrum: Hann-windowed 2D periodogram; if pixels/mm is supplied, frequency axes are expressed in cycles/mm and PSD is scaled to signal²·mm².
- Radial averaging is a compact diagnostic. Keep the full 2D spectrum for detecting directional/non-isotropic structure in future versions.

The PSD implementation is a periodogram diagnostic, not a complete standardized NPS measurement. Windowing, finite ROI, detrending, scanner MTF and aliasing still affect results. For publication-grade NPS, define a separate validated protocol and uncertainty calculation.

## Experimental design for first physical stock

Target stock: Kodak TRI-X 400, but do not mix 35 mm and 120 samples as if their scan magnification were the same.

For one stock/process combination:
1. Use at least three independent frames or separately exposed samples.
2. Include a calibrated step wedge or uniform fields with at least five net-density levels; record actual net diffuse density where possible. Display RGB codes are not density.
3. Acquire at least two independent scans of a stable sample if scanner repeatability is to be assessed.
4. Preserve 16-bit TIFF masters. Disable sharpening, grain reduction, automatic contrast, resizing and infrared dust removal where possible.
5. Record optical sampling and calibrate scanner response. Measure scanner/detector noise independently; do not simply subtract an arbitrary flatbed scan.
6. Use multiple non-overlapping ROIs per density and sample; report sample-to-sample variation and confidence intervals.
7. Fit density-dependent RMS and 2D NPS/PSD jointly. Hold out at least one sample/frame for validation.

## Research model direction

For silver-image B&W film, use a stochastic developed-image model with signal-dependent statistics and explicit spatial scale, then account separately for development spread, optical blur and scanner sampling. A random-dot/Monte-Carlo model is a strong research candidate (Newson et al., 2017); filtered Gaussian fields may be a computational approximation only after fitting measured statistics. Do not equate the simulated dots with literal crystallites without microscopy evidence.

The 2017 Newson et al. work supplies a physically motivated stochastic rendering approach and open reference implementation. A 2026 paper by Tian & Pappas reports an efficient random-dot model accounting for signal dependence, spatial correlation, magnification and optical blur. These are algorithmic references, not stock-specific measured Tri-X parameter sets.

## Sources

- ISO, **ISO 10505:2009 — Photography — Root mean square granularity of photographic films — Method of measurement**. Official ISO catalogue: https://www.iso.org/standard/50747.html (standard preview/catalogue). A publicly mirrored copy was consulted for method details; obtain the official standard for formal compliance work.
- Kodak, **KODAK PROFESSIONAL TRI-X 320 and 400 Films**, F-4017, September 2002, image-structure section, printed p. 10: https://125px.com/docs/unsorted/kodak/f4017.pdf
- HARMAN/Ilford, **HP5 PLUS Technical Data Sheet**, linked from official product page: https://www.ilfordphoto.com/amfile/file/download/file/1903/product/695/
- HARMAN/Ilford official HP5 Plus product page: https://www.ilfordphoto.com/hp5-plus-sheet-film
- Newson, Faraj, Galerne & Delon, **Realistic Film Grain Rendering**, Image Processing On Line 7 (2017), pp. 165–183; paper, demo and source: https://www.ipol.im/pub/art/2017/192/
- Newson, Delon & Galerne, **A Stochastic Film Grain Model for Resolution-Independent Rendering**, Computer Graphics Forum 36(8), 2017, DOI: https://doi.org/10.1111/cgf.13159
- Takano, **Granularity of Photographic Image (II): Wiener Spectrum at a Constant Density Level with Various Exposure and Time of Development**, 1968/1969: https://doi.org/10.11454/photogrst1964.31.209
- Doerner, **Wiener-Spectrum Analysis of Photographic Granularity**, JOSA 52(6), 1962, pp. 669–672, DOI: https://doi.org/10.1364/JOSA.52.000669
- Tian & Pappas, **Efficient Digital Film Grain Simulation**, IEEE Transactions on Image Processing 35 (2026), pp. 8851–8862, DOI: https://doi.org/10.1109/TIP.2026.3719463. Bibliographic record/abstract: https://pubmed.ncbi.nlm.nih.gov/42566361/

## v0.3 corrections and additional diagnostics

- Corrected a reporting bug: `mean_signal` now reports the ROI mean before detrending (v0.2 accidentally reported the mean of the mean-subtracted ROI, approximately zero).
- Added optional constant/planar detrending. The default plane fit removes a first-order illumination slope before texture statistics; always inspect the original ROI and do not use aggressive detrending to hide real low-frequency film structure.
- Added a Parseval consistency check between the 2-D periodogram integral and the Hann-window-weighted variance. This is a numerical implementation check, not evidence that the scan itself is calibrated.
- The full 2-D autocorrelation and 2-D periodogram, with frequency axes, are now saved in per-ROI NPZ files. Radial averages remain diagnostic only; they can conceal directional scanner structure.
- Added `transmittance_to_density(T, T_base) = -log10(T/T_base)` for linear, calibrated transmission data. This must not be applied to arbitrary positive scans or normalized grayscale PNGs: `T_base` must represent the clear-film base-plus-fog transmission in the same calibrated signal domain.
- The constant-field threshold now suppresses floating-point residue from planar least-squares detrending.

The 2-D periodogram uses a separable Hann window and is normalized so its integral over the frequency grid recovers the window-weighted variance (Parseval check). It remains an estimator for finite sampled images, not a standards-compliant NPS measurement. A calibrated density domain, scanner MTF/noise characterization, sampling calibration, independent ROIs and uncertainty analysis are still required.


## v0.4: channel-preserving acquisition and scan-domain cautions

- The analyzer now defaults to `native`: integer pixel values are normalized by their declared container/significant bit depth, but no sRGB transfer function or luma mix is guessed. A user must explicitly select `linear` or `srgb` when the encoding is known. Embedded ICC profiles are detected as metadata but are not silently applied.
- RGB scans are measured channel-by-channel. The bench reports covariance and correlation of detrended channel residuals, but does **not** subtract an estimated scanner-noise component. Such subtraction requires a validated scanner-specific model; common-channel covariance alone is not proof that the common component is exclusively silver-grain signal.
- Basic TIFF metadata (bit depth, resolution tags, software tag, ICC-profile presence) is recorded. TIFF resolution tags are not automatically trusted as physical sampling calibration: images may have been resized or resampled after scanning. Physical `px/mm` remains an explicit user-supplied parameter.
- The analyzer's values are scan-domain statistics. Converting scan values to optical density requires calibrated *linear transmittance* and a matched base-plus-fog reference. Inversion, automatic levels, nonlinear tone curves, sharpening, grain reduction and multi-pass scan averaging can alter the statistics.
- ISO 10505:2009 is confirmed current by ISO in its 2025 review. It specifies intrinsic RMS granularity of the photographic layer and explicitly does not cover Wiener/NPS estimation. The bench is not an ISO 10505 instrument.
- Newson et al. (IPOL 2017) describe an inhomogeneous Boolean model: Poisson-distributed grain centers, a grain-radius distribution (including log-normal options), signal-dependent point intensity, then a filtering/observation step. This is a useful physically motivated baseline, but its parameters are not a Tri-X calibration. Its article/code carries CC-BY-NC-SA / GPL terms as listed on IPOL; do not copy its implementation into this project's code without a deliberate license review.

## v0.4 validation

Eleven automated tests now cover 16-bit precision, native-vs-sRGB transfer behavior, separate RGB channel measurements, cross-channel covariance, white/correlated noise, constant fields including floating-point plane-fit residue, plane detrending, density conversion, physical frequency axis, Parseval consistency, and full 2-D export. These tests validate software behavior only, not a film profile.


### Numerical edge case fixed during v0.4 validation

A synthetic flat patch with a non-binary floating-point mean left least-squares plane-fit residue around 1e-14; the previous near-zero variance cutoff was too strict and reported a false, extremely long correlation. The cutoff is now scale-relative at 1e-24 in variance, and a dedicated regression test confirms that this numerical residue is treated as a constant field. This is a numerical tolerance for normalized image data, not a physical noise floor.


## v0.5: projection-density and aperture handling

The analyzer now has an explicitly opt-in calibration path for grayscale scans whose stored values are already linear with transmitted light. Given measured scanner dark signal `S_dark`, clear-path signal `S_clear`, and processed unexposed base-plus-fog signal `S_base`, it computes:

`T = (S - S_dark) / (S_clear - S_dark)`

`T_base = (S_base - S_dark) / (S_clear - S_dark)`

`D_net,projection = -log10(T / T_base)`

This is a calibrated net **projection optical density** under the affine scanner-response assumption. It is not automatically diffuse transmission density. ISO 10505 specifies conversion from projection to diffuse density and a diffuse conversion factor depending on the optical geometry; our bench does not implement that conversion. Do not use these results as ISO diffuse RMS or compare them directly to Kodak's published diffuse RMS values.

An optional sampled circular aperture diagnostic applies a 48 µm geometric disk average to the projection-density image, then calculates RMS after planar detrending. At 4000 true optical dpi, 48 µm corresponds to about 7.56 pixels. This is a useful aperture-equivalent comparison of scan data, but it does not reproduce the standard's illumination spectrum, microdensitometer objective numerical apertures/OTF, diffuse conversion factor, instrument-noise correction, statistical median estimator, or confidence intervals. It is not ISO-conformant.

ISO 10505:2009 specifies a 48.0 ± 0.5 µm effective circular aperture (or a 42.5 µm square aperture giving comparable results within 5 %), requires density conversion before RMS calculation, requires instrument noise to be accounted for, and requires reporting confidence limits. It recommends expanded uncertainty below ±6 % of the expected RMS value. The standard was confirmed in 2025 and remains current according to the ISO catalogue. The publicly mirrored PDF is used here only to inspect technical clauses; formal compliance requires the official standard.

New v0.5 tests validate only the numerical operations: dark/clear calibration recovers a known synthetic net density, the sampled disk kernel is normalized and has the expected physical width, under-sampled aperture settings are rejected, constant density remains zero after filtering, and the complete CLI analysis reports projection-density/aperture fields. None of these tests validates the scanner calibration of a real negative.

## v0.5 source additions

- ISO 10505:2009 technical clauses 4.2.6, 5.1, 5.3, 9.4–9.7 and Table 1, consulted through a public mirror: https://standards.isodoc.my/iso/ISO%2010505-2009%20PDF.pdf
- ISO 10505 catalogue record and 2025 confirmation: https://www.standardspavilion.org/sites/isoorg/contents/data/standard/05/07/50747.html
- Fujifilm Professional Film Data Guide, RMS definition and 48 µm aperture: https://asset.fujifilm.com/www/ca/files/2020-03/d52487c5c6f84e7f935c299491c5c1ff/ProfessionalFilmDataGuide.pdf
- Kodak Essential Reference Guide, 48 µm microdensitometer aperture and net diffuse density 1.00 above base: https://www.kodak.com/content/products-brochures/Film/kodak-essential-reference-guide-for-filmmakers.pdf


## v0.6: independent stochastic Boolean reference prototype

Added `boolean_grain_model.py`, an independent research implementation based on the published mathematical description of the inhomogeneous Boolean film-grain model. For homogeneous fields, the intensity is set from `lambda = ln(10) D / E[A]`, so the model's expected uncovered fraction (mean negative transmittance) is `10^-D`. Grain centers are Poisson-distributed, radii are constant or log-normal, and a separate Gaussian observation blur is optional.

The prototype outputs transmittance rather than converting a binary-coverage field back to density after filtering. This avoids artificial, arbitrarily high density spikes where the rasterized opaque-disk union fully covers a pixel. The flat-field expectation is checked statistically, not asserted to hold exactly for every finite realization. Variable-tone images are a local-intensity approximation because grains can overlap across tone boundaries.

This is a 2-D opaque-disk abstraction. It does not model literal silver-halide crystal morphology, latent-image formation, development chemistry, adjacency effects, gelatin, or scanner-specific MTF. The example parameters are arbitrary and must not be labelled Tri-X or HP5. The model remains outside the Android app until actual scans constrain its radius distribution, spatial spectrum, density response and observation blur.

## v0.6 Grainifier README review

The currently indexed public README for `grainifier/grainifier` reports that the HP5 Plus profile is EI 1600 (+2), with 114 single-pass frames in the reference profile, while Kodak Double-X 5222 is EI 250 with 124 single-pass frames. The README attributes the scans to Leica M6 negatives, lab development, Nikon Coolscan V ED at 4000 dpi and VueScan RAW DNG. It says the original raw scans remain private and the public 728-frame dataset contains per-patch statistics and per-bin spectra rather than image content. The stated license is MIT for software and CC BY 4.0 for profiles/dataset.

This is a promising and unusually relevant external reference, but the above are statements from the repository README, not an independent audit of its source code or raw data. The published statistics can support a methodological comparison if the exact profile files and dataset are obtained and their schemas/checksums are verified. They cannot support independent re-measurement of the private negatives. HP5 EI 1600 must not be relabelled as box-speed HP5 400. No Grainifier profile values are imported into Emulsion in v0.6.

Source: https://github.com/grainifier/grainifier (public README as indexed 2026-11-08).

## v0.6: empirical PSD-controlled Gaussian field baseline

Added `spectral_grain_model.py`, an independent statistical synthesis path. It generates a stationary Gaussian random field in the Fourier domain from a normalized mixture of Gaussian covariance components plus an optional white floor. A user-supplied piecewise-linear `sigma(D)` curve modulates local residual amplitude in net-density space. A shape-only least-squares fitter estimates two spatial scales, their mixture weight and a white floor from a radial PSD profile. `fit_spectral_profile.py` reads a physical-frequency 2-D PSD exported by the bench and produces a JSON fit.

This model is explicitly **phenomenological**. It matches second-order statistics (PSD/covariance) and a density-dependent variance curve, but does not model silver-halide crystals, latent-image formation, development, particle overlap, non-Gaussian tails, or bright/dark grain polarity. It is a useful low-cost candidate and an ablation baseline, not a physical replacement for Boolean/random-dot models. FFT synthesis is periodic on the sampled rectangle; production use needs overlap/tile handling and validation against seam artefacts.

A synthetic side-by-side diagnostic is saved in `results/model_comparison_synthetic/`. It deliberately does not convert Boolean binary coverage into optical density: fully covered pixels have zero transmittance and therefore infinite density, so arbitrary epsilon clipping would manufacture a false high-density tail. The two model outputs remain in their native domains in the figure. This is a meaningful warning: a binary Boolean coverage mask is not yet a calibrated continuous-density negative. A physically justified per-grain optical extinction/transmission model, calibrated to real data, is required before density-domain comparison.

### New literature reviewed in v0.6

- Zhang, Wang, Tian & Pappas (2023), *Film Grain Rendering and Parameter Estimation*, ACM TOG 42(4), DOI 10.1145/3592127. The abstract reports a fast statistical approximation derived from a Boolean model and parameter-estimation formulas from scanned grain images. The public SIGGRAPH/ACM abstract is available; the full ACM paper is access-restricted in the sources checked. Its method is a candidate for a future implementation after a careful mathematical review, not copied here.
- Tian & Pappas (2026), *Efficient Digital Film Grain Simulation*, IEEE TIP 35, 8851–8862, DOI 10.1109/TIP.2026.3719463. The PubMed metadata/abstract describes a random-dot approach designed for signal dependence, spatial correlation, magnification and blur, with improved efficiency over Monte Carlo in difficult regimes. Only the abstract/metadata was available in this review; no implementation or quantitative claims beyond that abstract are adopted.
- Lesné, Gousseau, Ladjal & Newson (2025), *Neural Film Grain Rendering*, Computer Graphics Forum 44(2), DOI 10.1111/cgf.70076. The abstract describes a lightweight neural network and texture-aware loss for efficient rendering of large grain/high resolutions. This is a promising later option, but would require a suitable training/reference corpus and held-out validation; current Emulsion data are insufficient to train or validate it.
- ISO 10505:2009 remains current after 2025 review and explicitly excludes Wiener/NPS estimation from its scope. RMS and NPS therefore remain separate acceptance tracks.

Sources:
- https://dl.acm.org/doi/10.1145/3592127
- https://www.siggraph.org/wp-content/uploads/2024/02/ACM-Transactions-on-Graphics-Volume-42-Issue-4.html
- https://pubmed.ncbi.nlm.nih.gov/42566361/
- https://onlinelibrary.wiley.com/doi/10.1111/cgf.70076
- https://www.iso.org/standard/50747.html
