package com.emulsion.editor

import kotlin.math.pow

/**
 * Physically-inspired stochastic grain model.
 * This is a research prototype, not yet calibrated to a named commercial emulsion.
 * Grain is represented by correlated random fields at several spatial scales,
 * with a signal-dependent variance curve and partially correlated RGB channels.
 */
data class GrainSettings(
    val amount: Float = 0.42f,
    val grainDiameterMicrons: Float = 9.0f,
    val sizeSpread: Float = 0.62f,
    val clumping: Float = 0.48f,
    val toneDependence: Float = 0.72f,
    val chroma: Float = 0.18f,
    val format: FilmFormat = FilmFormat.MM35,
    val model: GrainModelMode = GrainModelMode.CORRELATED_FIELD,
    val monochrome: Boolean = false, // neutral grain across RGB channels
    val blackAndWhite: Boolean = false, // convert the photograph itself to grayscale
    val vintage: Float = 0f, // Gaussian softness after grain
    val dustEnabled: Boolean = false,
    val dustMode: DustMode = DustMode.BLACK,
    val dustDensity: Float = 0.22f,
    val dustSize: Float = 1.0f,
    val dustBlur: Float = 0f,
    val dustSeed: Long = 918273L,
    val motionBlur: Float = 0f,
    val motionAngle: Float = 0.0f,
    val edgeSoftness: Float = 0f,
    val halation: Float = 0f,
    val halationRadius: Float = 8f,
    val halationThreshold: Float = 0.72f,
    val chromaticAberration: Float = 0f,
    val fade: Float = 0f,
    val blackLift: Float = 0f,
    val desaturation: Float = 0f,
    val whiteCompression: Float = 0f,
    val whiteLevel: Float = 1f,
    val blackLevel: Float = 0f,
    val blackTint: Float = 0.5f,
    val emulsionScattering: Float = 0f,
    val bleachBypass: Float = 0f,
    val adjacency: Float = 0f,
    val adjacencyRadius: Float = 3f,
    val bindGrainToFormat: Boolean = true,
    val smoothGrainContours: Boolean = false,
    val grainOpticalBlurMicrons: Float = 2f,
    val showBorder: Boolean = false,
    val matteWidth: Float = 0.045f,
    val darkMatte: Boolean = false,
    val shadowResponse: Float = 0.75f,
    val highlightResponse: Float = 0.55f,
    val seed: Long = 73421L
)

enum class DustMode(val label: String) {
    BLACK("Чёрная"),
    WHITE("Белая"),
    MIXED("Смешанная")
}

enum class GrainModelMode(val label: String) {
    CORRELATED_FIELD("Коррелированное поле"),
    PARTICLE_FIELD("Частичное поле · эксперимент")
}

enum class FilmFormat(val label: String, val widthMm: Float) {
    MM35("35 mm", 36f),
    MEDIUM("120 / 6×6", 56f),
    LARGE("4×5 inch", 127f)
}

object GrainRenderer {
    /**
     * Renders a full-resolution ARGB_8888 bitmap. Caller should execute off the UI thread.
     * The source is treated as a positive scan; luminance is used as a proxy for negative
     * exposure. A calibrated implementation will replace this proxy with measured H-D curves.
     */
    fun render(source: android.graphics.Bitmap, settings: GrainSettings): android.graphics.Bitmap {
        val w = source.width
        val h = source.height
        val inputRow = IntArray(w)
        val outputRow = IntArray(w)
        val output = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)

        val grainPx = (if (settings.bindGrainToFormat) settings.grainDiameterMicrons / (settings.format.widthMm * 1000f) * w else settings.grainDiameterMicrons / 10f)
            .coerceIn(0.55f, 8.0f)
        val spread = settings.sizeSpread.coerceIn(0f, 1f)
        val clump = settings.clumping.coerceIn(0f, 1f)
        val tone = settings.toneDependence.coerceIn(0f, 1f)
        val chroma = settings.chroma.coerceIn(0f, 1f)
        val amount = settings.amount.coerceIn(0f, 1f)
        val shadowResponse = settings.shadowResponse.coerceIn(0f, 1f)
        val highlightResponse = settings.highlightResponse.coerceIn(0f, 1f)

        // Coarse random fields create correlated grain clouds; a deterministic per-pixel
        // field retains particle-scale variation without allocating full-frame noise planes.
        val midCell = (grainPx * (2.2f + clump * 2.8f)).coerceAtLeast(2.0f)
        val coarseCell = (grainPx * (6.0f + clump * 7.0f)).coerceAtLeast(4.0f)
        val mid = NoiseField(w, h, midCell, settings.seed xor 0x6B21L)
        val coarse = NoiseField(w, h, coarseCell, settings.seed xor 0x44D3L)

        val commonWeight = (1f - chroma * 0.62f).coerceIn(0.25f, 1f)
        val independentWeight = (chroma * 0.72f)
        val midWeight = 0.30f + clump * 0.12f
        val coarseWeight = 0.10f + clump * 0.18f
        val fineWeight = 0.78f - spread * 0.12f
        val norm = 1f / (fineWeight + midWeight + coarseWeight)
        val scale = amount * 0.075f

        for (y in 0 until h) {
            source.getPixels(inputRow, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val p = inputRow[x]
                val a = (p ushr 24) and 0xff
                val sr = ((p ushr 16) and 0xff) / 255f
                val sg = ((p ushr 8) and 0xff) / 255f
                val sb = (p and 0xff) / 255f

                // Convert sRGB to linear light before adding density-like fluctuations.
                var r = srgbToLinear(sr)
                var g = srgbToLinear(sg)
                var b = srgbToLinear(sb)
                if (settings.blackAndWhite) {
                    val luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b
                    r = luminance
                    g = luminance
                    b = luminance
                }
                val yLum = (0.2126f * r + 0.7152f * g + 0.0722f * b).coerceIn(0f, 1f)

                val fineNoise = uniformNoise(x, y, settings.seed xor 0x19A4L)
                val field = (fineNoise * fineWeight +
                    mid.sample(x, y) * midWeight + coarse.sample(x, y) * coarseWeight) * norm
                // Experimental thresholded field evokes clustered particle occupancy. It is
                // not the validated Boolean disk/overlap model from the Python research bench.
                val base = if (settings.model == GrainModelMode.PARTICLE_FIELD) {
                    val thresholded = if (field > 0.18f) 0.72f else -0.38f
                    (thresholded * 0.72f + field * 0.28f)
                } else field

                // A smooth variance curve: grain strength depends on local signal, rather
                // than being a constant-amplitude overlay. Kept nonzero near both endpoints.
                val exposureProxy = yLum.coerceIn(0.015f, 0.985f)
                val shadow = shadowResponse * (1f - kotlin.math.sqrt(exposureProxy))
                val highlight = highlightResponse * kotlin.math.sqrt(exposureProxy)
                val densityResponse = (0.20f + 0.55f * kotlin.math.sqrt(exposureProxy) + 0.25f * (shadow + highlight))
                val toneCurve = (1f - tone) + tone * densityResponse
                val sigma = scale * toneCurve

                val nr = base * commonWeight + uniformNoise(x, y, settings.seed xor 0x12345L) * independentWeight
                val ng = base * commonWeight + uniformNoise(x, y, settings.seed xor 0x6789AL) * independentWeight
                val nb = base * commonWeight + uniformNoise(x, y, settings.seed xor 0xABCDEFL) * independentWeight

                val monoNoise = (nr + ng + nb) / 3f
                val rr = linearToSrgb((r + (if (settings.monochrome) monoNoise else nr) * sigma).coerceIn(0f, 1f))
                val gg = linearToSrgb((g + (if (settings.monochrome) monoNoise else ng) * sigma).coerceIn(0f, 1f))
                val bb = linearToSrgb((b + (if (settings.monochrome) monoNoise else nb) * sigma).coerceIn(0f, 1f))
                outputRow[x] = (a shl 24) or
                    ((rr * 255f + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                    ((gg * 255f + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                    (bb * 255f + 0.5f).toInt().coerceIn(0, 255)
            }
            output.setPixels(outputRow, 0, w, 0, y, w, 1)
        }
        var result = output
        if (settings.smoothGrainContours) result = gaussianBlur(result, 0.35f + settings.grainOpticalBlurMicrons.coerceIn(0f, 8f) * 0.10f)
        if (settings.motionBlur > 0f) result = directionalBlur(result, settings.motionBlur, settings.motionAngle)
        if (settings.edgeSoftness > 0f) result = radialEdgeSoftness(result, settings.edgeSoftness)
        if (settings.halation > 0f) result = applyHalation(result, settings.halation, settings.halationRadius, settings.halationThreshold)
        if (settings.emulsionScattering > 0f) result = applyGlow(result, settings.emulsionScattering)
        if (settings.chromaticAberration > 0f && !settings.blackAndWhite) result = applyChromaticAberration(result, settings.chromaticAberration)
        result = applyToneEffects(result, settings)
        if (settings.dustEnabled && settings.dustDensity > 0f) {
            result = applyDust(result, settings.dustMode, settings.dustDensity, settings.dustSize, settings.dustBlur, settings.dustSeed)
        }
        if (settings.adjacency > 0f) result = applyAdjacency(result, settings.adjacency, settings.adjacencyRadius)
        if (settings.vintage > 0f) result = gaussianBlur(result, settings.vintage * 1.4f)
        if (settings.showBorder) result = addMatteBorder(result, settings.matteWidth, settings.darkMatte)
        return result
    }

    private fun pixels(bitmap: android.graphics.Bitmap): IntArray = IntArray(bitmap.width * bitmap.height).also { bitmap.getPixels(it, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height) }
    private fun fromPixels(src: IntArray, w: Int, h: Int): android.graphics.Bitmap = android.graphics.Bitmap.createBitmap(src, w, h, android.graphics.Bitmap.Config.ARGB_8888)
    private fun ch(p: Int, shift: Int) = (p ushr shift) and 255
    private fun pack(a: Int, r: Int, g: Int, b: Int) = (a.coerceIn(0,255) shl 24) or (r.coerceIn(0,255) shl 16) or (g.coerceIn(0,255) shl 8) or b.coerceIn(0,255)

    private fun gaussianBlur(bitmap: android.graphics.Bitmap, sigma0: Float): android.graphics.Bitmap {
        val sigma = sigma0.coerceIn(0.1f, 8f); val radius = kotlin.math.ceil(sigma * 2.5f).toInt().coerceIn(1, 20)
        val kernel = FloatArray(radius*2+1); var sum=0f
        for(k in -radius..radius){ val v=kotlin.math.exp(-(k*k).toFloat()/(2*sigma*sigma)); kernel[k+radius]=v; sum+=v }
        for(i in kernel.indices) kernel[i]/=sum
        val w=bitmap.width; val h=bitmap.height; val src=pixels(bitmap); val tmp=IntArray(src.size); val dst=IntArray(src.size)
        for(y in 0 until h) for(x in 0 until w){ var a=0f;var r=0f;var g=0f;var b=0f; for(k in -radius..radius){val q=src[y*w+(x+k).coerceIn(0,w-1)];val z=kernel[k+radius];a+=ch(q,24)*z;r+=ch(q,16)*z;g+=ch(q,8)*z;b+=ch(q,0)*z};tmp[y*w+x]=pack(a.toInt(),r.toInt(),g.toInt(),b.toInt()) }
        for(y in 0 until h) for(x in 0 until w){ var a=0f;var r=0f;var g=0f;var b=0f; for(k in -radius..radius){val q=tmp[(y+k).coerceIn(0,h-1)*w+x];val z=kernel[k+radius];a+=ch(q,24)*z;r+=ch(q,16)*z;g+=ch(q,8)*z;b+=ch(q,0)*z};dst[y*w+x]=pack(a.toInt(),r.toInt(),g.toInt(),b.toInt()) }
        return fromPixels(dst,w,h)
    }
    private fun directionalBlur(bitmap: android.graphics.Bitmap, amount: Float, angle: Float): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val dst=IntArray(src.size);val rad=(amount*8f).toInt().coerceIn(1,16);val dx=kotlin.math.cos(Math.toRadians(angle.toDouble())).toFloat();val dy=kotlin.math.sin(Math.toRadians(angle.toDouble())).toFloat()
        for(y in 0 until h)for(x in 0 until w){var a=0;var r=0;var g=0;var b=0;var n=0;for(i in -rad..rad step 2){val xx=(x+(dx*i).toInt()).coerceIn(0,w-1);val yy=(y+(dy*i).toInt()).coerceIn(0,h-1);val q=src[yy*w+xx];a+=ch(q,24);r+=ch(q,16);g+=ch(q,8);b+=ch(q,0);n++};dst[y*w+x]=pack(a/n,r/n,g/n,b/n)}
        return fromPixels(dst,w,h)
    }
    private fun radialEdgeSoftness(bitmap: android.graphics.Bitmap, amount: Float): android.graphics.Bitmap {
        val blurred=gaussianBlur(bitmap,0.5f+amount*3f);val w=bitmap.width;val h=bitmap.height;val a=pixels(bitmap);val b=pixels(blurred);val out=IntArray(a.size)
        for(y in 0 until h)for(x in 0 until w){val nx=(x-w/2f)/(w/2f);val ny=(y-h/2f)/(h/2f);val t=(((kotlin.math.sqrt(nx*nx+ny*ny)-0.35f)/0.65f).coerceIn(0f,1f)*amount);val i=y*w+x;out[i]=pack(ch(a[i],24), (ch(a[i],16)*(1-t)+ch(b[i],16)*t).toInt(),(ch(a[i],8)*(1-t)+ch(b[i],8)*t).toInt(),(ch(a[i],0)*(1-t)+ch(b[i],0)*t).toInt()) }
        return fromPixels(out,w,h)
    }
    private fun applyHalation(bitmap: android.graphics.Bitmap, amount: Float, radius: Float, threshold: Float): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val mask=IntArray(src.size){i->val p=src[i];val lum=(ch(p,16)*0.2126f+ch(p,8)*0.7152f+ch(p,0)*0.0722f)/255f;val v=((lum-threshold.coerceIn(0.1f,0.98f))/(1f-threshold.coerceIn(0.1f,0.98f))).coerceIn(0f,1f);pack(255,(v*255).toInt(),0,0)}
        val blurred=gaussianBlur(fromPixels(mask,w,h),(radius/8f).coerceIn(1f,12f));val glow=pixels(blurred);val out=IntArray(src.size)
        for(i in src.indices){val g=ch(glow[i],16)/255f*amount*0.55f;val p=src[i];out[i]=pack(255,(ch(p,16)+g*255).toInt(),(ch(p,8)+g*55).toInt(),(ch(p,0)+g*25).toInt())};return fromPixels(out,w,h)
    }
    private fun applyGlow(bitmap: android.graphics.Bitmap, amount: Float): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val blur=pixels(gaussianBlur(bitmap,1f+amount*5f));val out=IntArray(src.size)
        for(i in src.indices){val p=src[i];val q=blur[i];val lum=(ch(p,16)+ch(p,8)+ch(p,0))/765f;val k=amount*0.35f*(0.25f+lum);out[i]=pack(255,(ch(p,16)*(1-k)+ch(q,16)*k).toInt(),(ch(p,8)*(1-k)+ch(q,8)*k).toInt(),(ch(p,0)*(1-k)+ch(q,0)*k).toInt())};return fromPixels(out,w,h)
    }
    private fun applyChromaticAberration(bitmap: android.graphics.Bitmap, amount: Float): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val out=IntArray(src.size);val shift=(amount*4f).toInt().coerceIn(1,8)
        for(y in 0 until h)for(x in 0 until w){val dx=x-w/2;val dy=y-h/2;val len=kotlin.math.sqrt((dx*dx+dy*dy).toFloat()).coerceAtLeast(1f);val ox=(dx/len*shift).toInt();val oy=(dy/len*shift).toInt();val pr=src[(y+oy).coerceIn(0,h-1)*w+(x+ox).coerceIn(0,w-1)];val pg=src[y*w+x];val pb=src[(y-oy).coerceIn(0,h-1)*w+(x-ox).coerceIn(0,w-1)];out[y*w+x]=pack(255,ch(pr,16),ch(pg,8),ch(pb,0))};return fromPixels(out,w,h)
    }
    private fun applyToneEffects(bitmap: android.graphics.Bitmap, s: GrainSettings): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val out=IntArray(src.size)
        for(i in src.indices){val p=src[i];var r=ch(p,16)/255f;var g=ch(p,8)/255f;var b=ch(p,0)/255f
            val lum=0.2126f*r+0.7152f*g+0.0722f*b
            if(s.bleachBypass>0f){val gray=lum;val sat=1f-s.bleachBypass*0.72f;r=gray+(r-gray)*sat;g=gray+(g-gray)*sat;b=gray+(b-gray)*sat;val c=1f+s.bleachBypass*0.65f;r=(r-0.5f)*c+0.5f;g=(g-0.5f)*c+0.5f;b=(b-0.5f)*c+0.5f}
            val fade=s.fade.coerceIn(0f,1f);val lift=s.blackLift.coerceIn(0f,1f)*fade*0.22f;r=r*(1f-lift)+lift;g=g*(1f-lift)+lift;b=b*(1f-lift)+lift
            val des=s.desaturation.coerceIn(0f,1f)*fade;val y=0.2126f*r+0.7152f*g+0.0722f*b;r=y+(r-y)*(1f-des);g=y+(g-y)*(1f-des);b=y+(b-y)*(1f-des)
            val lo=s.blackLevel.coerceIn(0f,0.4f); val hi=s.whiteLevel.coerceIn(0.6f,1f)
            val range=(hi-lo).coerceAtLeast(0.2f); r=((r-lo)/range).coerceIn(0f,1f);g=((g-lo)/range).coerceIn(0f,1f);b=((b-lo)/range).coerceIn(0f,1f)
            val tint=(s.blackTint-0.5f)*fade*0.12f; r+=tint; b-=tint
            val comp=s.whiteCompression.coerceIn(0f,1f)*0.5f;r=r/(1f+comp*r);g=g/(1f+comp*g);b=b/(1f+comp*b)
            out[i]=pack(255,((r*(1f-fade*0.08f)+fade*0.04f)*255).toInt(),((g*(1f-fade*0.08f)+fade*0.04f)*255).toInt(),((b*(1f-fade*0.08f)+fade*0.04f)*255).toInt()) }
        return fromPixels(out,w,h)
    }
    /**
     * Experimental procedural dust overlay. The 50 archetypes below are synthetic
     * shape prototypes, NOT authentic scans. Real corpus crops can replace this bank
     * after their source image redistribution terms and assets are verified.
     */
    private fun applyDust(bitmap: android.graphics.Bitmap, mode: DustMode, density: Float, size: Float, blur: Float, seed: Long): android.graphics.Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val overlay = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(overlay)
        val rng = java.util.Random(seed)
        val baseCount = (w.toLong() * h.toLong() / 18000L).coerceAtMost(18000L).toInt()
        val count = (baseCount * density.coerceIn(0f, 1f) * 2.4f).toInt().coerceAtLeast(0)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.FILL }
        val path = android.graphics.Path()
        val scale = size.coerceIn(0.25f, 4f) * (minOf(w, h) / 1400f).coerceIn(0.45f, 3.2f)
        for (i in 0 until count) {
            val shape = DustShapeLibrary.templates[rng.nextInt(DustShapeLibrary.templates.size)]
            val cx = rng.nextFloat() * w
            val cy = rng.nextFloat() * h
            val radius = (0.35f + rng.nextFloat().pow(2) * 1.7f) * scale
            val angle = rng.nextFloat() * (Math.PI * 2.0).toFloat()
            val isWhite = when (mode) {
                DustMode.BLACK -> false
                DustMode.WHITE -> true
                DustMode.MIXED -> rng.nextBoolean()
            }
            val alpha = 110 + rng.nextInt(146)
            paint.color = if (isWhite) android.graphics.Color.WHITE else android.graphics.Color.BLACK
            paint.alpha = alpha
            path.reset()
            for (v in 0 until shape.vertices) {
                val phase = (v.toFloat() / shape.vertices) * (Math.PI * 2.0).toFloat()
                val irregular = shape.radii[v] * (0.78f + rng.nextFloat() * 0.44f)
                val lx = kotlin.math.cos(phase) * radius * irregular * shape.aspect
                val ly = kotlin.math.sin(phase) * radius * irregular / shape.aspect.coerceAtLeast(0.25f)
                val x = cx + lx * kotlin.math.cos(angle) - ly * kotlin.math.sin(angle)
                val y = cy + lx * kotlin.math.sin(angle) + ly * kotlin.math.cos(angle)
                if (v == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, paint)
            if (rng.nextFloat() < 0.10f && blur <= 0.01f) {
                paint.alpha = (alpha * 0.16f).toInt()
                canvas.drawCircle(cx, cy, radius * 1.55f, paint)
            }
        }
        val softened = if (blur > 0.01f) gaussianBlur(overlay, blur.coerceIn(0.1f, 4f)) else overlay
        val src = pixels(bitmap)
        val mask = pixels(softened)
        val out = IntArray(src.size)
        for (i in src.indices) {
            val a = ch(mask[i], 24) / 255f
            if (a < 0.001f) out[i] = src[i]
            else out[i] = pack(ch(src[i], 24),
                (ch(src[i], 16) * (1f - a) + ch(mask[i], 16) * a).toInt(),
                (ch(src[i], 8) * (1f - a) + ch(mask[i], 8) * a).toInt(),
                (ch(src[i], 0) * (1f - a) + ch(mask[i], 0) * a).toInt())
        }
        if (softened !== overlay) softened.recycle()
        overlay.recycle()
        return fromPixels(out, w, h)
    }

    private object DustShapeLibrary {
        // 50 reproducible procedural archetypes; these are not scanned dust samples.
        val templates: List<DustShape> = (0 until 50).map { index ->
            val random = java.util.Random(0xD057L + index * 7919L)
            val vertices = 5 + random.nextInt(6)
            val radii = FloatArray(vertices) { 0.55f + random.nextFloat() * 0.9f }
            DustShape(vertices, radii, 0.55f + random.nextFloat() * 1.35f)
        }
    }

    private data class DustShape(val vertices: Int, val radii: FloatArray, val aspect: Float)

    private fun applyAdjacency(bitmap: android.graphics.Bitmap, amount: Float, radius: Float): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val src=pixels(bitmap);val blur=pixels(gaussianBlur(bitmap,radius.coerceIn(1f,8f)));val out=IntArray(src.size)
        for (i in src.indices) {
            val p = src[i]
            val q = blur[i]
            val edge: (Int) -> Int = { shift ->
                ((ch(p, shift) - ch(q, shift)) * amount * 0.65f).toInt()
            }
            out[i] = pack(
                255,
                (ch(p, 16) + edge(16)).coerceIn(0, 255),
                (ch(p, 8) + edge(8)).coerceIn(0, 255),
                (ch(p, 0) + edge(0)).coerceIn(0, 255)
            )
        }
        return fromPixels(out, w, h)
    }
    private fun addMatteBorder(bitmap: android.graphics.Bitmap, width: Float, dark: Boolean): android.graphics.Bitmap {
        val w=bitmap.width;val h=bitmap.height;val pad=(minOf(w,h)*width.coerceIn(0.01f,0.15f)).toInt().coerceAtLeast(4);val out=android.graphics.Bitmap.createBitmap(w+pad*2,h+pad*2,android.graphics.Bitmap.Config.ARGB_8888);val canvas=android.graphics.Canvas(out);canvas.drawColor(if(dark) android.graphics.Color.rgb(28,27,25) else android.graphics.Color.rgb(238,235,226));val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG);canvas.drawBitmap(bitmap,pad.toFloat(),pad.toFloat(),paint);return out
    }

    /** Separable Gaussian low-pass applied after grain, so both image detail and grain soften. */
    private fun applyVintageSoftness(bitmap: android.graphics.Bitmap, amount: Float): android.graphics.Bitmap {
        val sigma = amount.coerceIn(0f, 1f) * 1.4f
        if (sigma < 0.08f) return bitmap
        val radius = kotlin.math.ceil(sigma * 3f).toInt().coerceIn(1, 5)
        val kernel = FloatArray(radius * 2 + 1)
        var total = 0f
        for (i in -radius..radius) {
            val weight = kotlin.math.exp(-(i * i).toFloat() / (2f * sigma * sigma))
            kernel[i + radius] = weight
            total += weight
        }
        for (i in kernel.indices) kernel[i] /= total
        val w = bitmap.width
        val h = bitmap.height
        val src = IntArray(w * h)
        val tmp = IntArray(w * h)
        val dst = IntArray(w * h)
        bitmap.getPixels(src, 0, w, 0, 0, w, h)
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0f; var r = 0f; var g = 0f; var b = 0f
            for (k in -radius..radius) {
                val p = src[y * w + (x + k).coerceIn(0, w - 1)]
                val q = kernel[k + radius]
                a += ((p ushr 24) and 255) * q; r += ((p ushr 16) and 255) * q
                g += ((p ushr 8) and 255) * q; b += (p and 255) * q
            }
            tmp[y * w + x] = (a.toInt().coerceIn(0,255) shl 24) or (r.toInt().coerceIn(0,255) shl 16) or (g.toInt().coerceIn(0,255) shl 8) or b.toInt().coerceIn(0,255)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0f; var r = 0f; var g = 0f; var b = 0f
            for (k in -radius..radius) {
                val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                val q = kernel[k + radius]
                a += ((p ushr 24) and 255) * q; r += ((p ushr 16) and 255) * q
                g += ((p ushr 8) and 255) * q; b += (p and 255) * q
            }
            dst[y * w + x] = (a.toInt().coerceIn(0,255) shl 24) or (r.toInt().coerceIn(0,255) shl 16) or (g.toInt().coerceIn(0,255) shl 8) or b.toInt().coerceIn(0,255)
        }
        return android.graphics.Bitmap.createBitmap(dst, w, h, android.graphics.Bitmap.Config.ARGB_8888)
    }

    // Fast deterministic per-pixel white-noise source; coarse Gaussian fields above
    // provide the correlated component. Hashing avoids allocating full-frame noise planes.
    private fun uniformNoise(x: Int, y: Int, seed: Long): Float {
        var z = seed xor (x.toLong() * -7046029254386353131L) xor (y.toLong() * -4658895280553007687L)
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        z = z xor (z ushr 31)
        return ((z ushr 40).toInt() / 8388607.5f) - 1f
    }

    private fun srgbToLinear(v: Float): Float = if (v <= 0.04045f) v / 12.92f else Math.pow(((v + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    private fun linearToSrgb(v: Float): Float = if (v <= 0.0031308f) v * 12.92f else (1.055 * Math.pow(v.toDouble(), 1.0 / 2.4) - 0.055).toFloat()

    private class NoiseField(width: Int, height: Int, cell: Float, seed: Long) {
        private val step = cell.coerceAtLeast(0.5f)
        private val cols = (kotlin.math.ceil(width / step.toDouble()).toInt() + 2).coerceAtLeast(2)
        private val rows = (kotlin.math.ceil(height / step.toDouble()).toInt() + 2).coerceAtLeast(2)
        private val values = FloatArray(cols * rows)
        init {
            var s = seed
            for (i in values.indices) {
                s += -7046029254386353131L
                var z = s
                z = (z xor (z ushr 30)) * -4658895280553007687L
                z = (z xor (z ushr 27)) * -7723592293110705685L
                z = z xor (z ushr 31)
                val u1 = (((z ushr 11).toDouble() + 1.0) / (1L shl 53).toDouble()).coerceIn(1e-9, 1.0)
                s += -7046029254386353131L
                var z2 = s
                z2 = (z2 xor (z2 ushr 30)) * -4658895280553007687L
                z2 = (z2 xor (z2 ushr 27)) * -7723592293110705685L
                z2 = z2 xor (z2 ushr 31)
                val u2 = ((z2 ushr 11).toDouble() / (1L shl 53).toDouble()).coerceIn(0.0, 1.0)
                values[i] = (kotlin.math.sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)).toFloat().coerceIn(-3.5f, 3.5f)
            }
        }
        fun sample(px: Int, py: Int): Float {
            val gx = px / step
            val gy = py / step
            val x0 = gx.toInt().coerceIn(0, cols - 2)
            val y0 = gy.toInt().coerceIn(0, rows - 2)
            val tx = (gx - x0).coerceIn(0f, 1f)
            val ty = (gy - y0).coerceIn(0f, 1f)
            val a = values[y0 * cols + x0]
            val b = values[y0 * cols + x0 + 1]
            val c = values[(y0 + 1) * cols + x0]
            val d = values[(y0 + 1) * cols + x0 + 1]
            val top = a + (b - a) * tx
            val bottom = c + (d - c) * tx
            return top + (bottom - top) * ty
        }
    }
}
