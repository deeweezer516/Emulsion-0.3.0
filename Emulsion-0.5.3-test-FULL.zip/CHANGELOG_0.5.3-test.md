# Emulsion 0.5.3-test

## Preview / export consistency for dust
- Dust particle count is now calculated in normalized frame space (reference long edge 1400 px), not raw pixel area.
- The same seed now produces the same normalized particle population and placement across preview and full-resolution export.
- Particle size and blur scale linearly with the long-edge resolution relative to the 1400 px preview reference.
- This is intended to make the exported image visually match the preview when both are viewed at the same display size.
- The Android app still requires device-side comparison; exact matching may be affected by Android bitmap scaling and JPEG compression.
